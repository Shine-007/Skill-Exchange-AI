# API Documentation — Skill Exchange & Micro-Mentorship Platform

Base URL: `http://localhost:8080/api`

Every endpoint returns a consistent JSON envelope:

```json
{
  "success": true,
  "message": "Human readable message",
  "data": { }
}
```

On error, `success` is `false`, `message` explains what went wrong, and
`data` is `null`. HTTP status codes are used correctly (`200`, `201`, `400`,
`401`, `404`, `500`).

---

## 1. Authentication

### POST /api/auth/register
Registers a new user and auto-creates an empty profile.

**Request body**
```json
{ "name": "Arjun Mehta", "email": "arjun@example.com", "password": "password123" }
```
**Response `201`**
```json
{
  "success": true,
  "message": "Registration successful",
  "data": { "token": "MS1mNzZjLi4u", "userId": 1, "name": "Arjun Mehta", "email": "arjun@example.com" }
}
```

### POST /api/auth/login
```json
{ "email": "arjun@example.com", "password": "password123" }
```
Response same shape as register. `401` on invalid credentials.

### POST /api/auth/logout
Header: `Authorization: <token>`. Invalidates the session token.

---

## 2. Users / Profile

### GET /api/users/{id}
Returns the full profile including skills offered/wanted and rating summary.

### PUT /api/users/{id}
```json
{
  "name": "Arjun Mehta",
  "photoUrl": "https://.../avatar.png",
  "bio": "Backend developer...",
  "interests": "Programming, Music",
  "learningGoals": "Learn React, Improve System Design",
  "preferredMentorshipType": "ONLINE"
}
```

### GET /api/users/{id}/dashboard
Returns aggregated dashboard data: `profileCompletion`, `skillsOffered`,
`skillsWanted`, `topMatches` (top 5 AI matches), `pendingRequests`,
`upcomingSessions`, `completedSessions`, `averageRating`, `totalRatings`.

---

## 3. Skills

### GET /api/skills
Returns the full skill catalog.

### POST /api/skills
```json
{ "skillName": "Kotlin", "category": "Programming" }
```
Adds a new skill to the shared catalog (idempotent — reuses existing skill if the name matches).

### POST /api/skills/user
Attach a skill to a user's profile as OFFERED or WANTED.
```json
{ "userId": 1, "skillName": "Java", "category": "Programming", "type": "OFFERED", "proficiency": "EXPERT" }
```

### GET /api/skills/user/{userId}?type=OFFERED
`type` is optional (`OFFERED` or `WANTED`); omit to get both.

### DELETE /api/skills/user/{userSkillId}?userId={userId}
Removes a skill from the user's profile.

### GET /api/skills/search?skillName=Java&proficiency=EXPERT
Search & discovery — finds all users who **offer** a given skill.
`proficiency` is optional.

---

## 4. AI Matching

### GET /api/matches/{userId}?limit=10
**The core AI matching endpoint.** Computes and ranks compatibility scores
between `userId` and every other active user.

**Response `data` (array, sorted by `overallMatch` descending)**
```json
[
  {
    "matchedUserId": 2,
    "matchedUserName": "Priya Sharma",
    "matchedUserPhoto": null,
    "averageRating": 4.5,
    "skillMatch": 95.0,
    "goalMatch": 90.0,
    "interestMatch": 80.0,
    "levelMatch": 85.0,
    "availabilityMatch": 100.0,
    "overallMatch": 90.25,
    "matchingSkills": ["React", "UI/UX Design"],
    "reason": "Recommended because Priya Sharma offers React, UI/UX Design, which match your learning goals. Their experience level is well-suited to mentor you."
  }
]
```

Scoring weights: Skill 50%, Goal 20%, Interest 15%, Level 10%, Availability 5%
(see `MatchingService.java` for the full algorithm).

---

## 5. Mentorship Requests

### POST /api/requests
```json
{ "senderId": 5, "receiverId": 1, "skillId": 1, "message": "Hi, could you mentor me?" }
```
Creates a request with status `PENDING`.

### GET /api/requests/{userId}
Returns every request where the user is sender **or** receiver.

### PUT /api/requests/{id}
```json
{ "status": "ACCEPTED" }
```
`status` must be one of `ACCEPTED`, `REJECTED`, `CANCELLED`. Only requests
currently `PENDING` can be updated.

---

## 6. Sessions

### POST /api/sessions
Schedules a micro-mentorship session from an **ACCEPTED** request.
```json
{
  "requestId": 2,
  "sessionDate": "2026-08-25",
  "startTime": "18:00",
  "durationMinutes": 30,
  "notes": "Focus on Spring Boot basics"
}
```
`durationMinutes` must be `15`, `30`, `45`, or `60`.

### GET /api/sessions/{userId}
Returns all sessions where the user is mentor or learner.

### PUT /api/sessions/{id}/complete
Marks a `SCHEDULED` session as `COMPLETED`.

### PUT /api/sessions/{id}/cancel
Marks a session as `CANCELLED`.

---

## 7. Ratings & Feedback

### POST /api/ratings
Submit a rating after a session is `COMPLETED`. Only session participants
may rate, and only once per session per rater.
```json
{ "sessionId": 2, "raterId": 3, "ratedUserId": 4, "stars": 5, "feedback": "Great mentor!" }
```

### GET /api/ratings/{userId}
Returns all ratings **received** by this user.

### GET /api/ratings/{userId}/summary
```json
{ "averageRating": 4.5, "totalRatings": 3 }
```

---

## 8. Availability

### POST /api/availability
```json
{ "userId": 1, "dayOfWeek": "MON", "startTime": "18:00", "endTime": "20:00" }
```

### GET /api/availability/{userId}
Returns all weekly time-slots for the user.

---

## 9. Error Response Examples

**Validation error (`400`)**
```json
{ "success": false, "message": "email: Email must be valid", "data": null }
```

**Business rule violation (`400`)**
```json
{ "success": false, "message": "A session can only be scheduled for an ACCEPTED request", "data": null }
```

**Not found (`404`)**
```json
{ "success": false, "message": "User not found", "data": null }
```
