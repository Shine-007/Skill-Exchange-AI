# Skill Exchange & Micro-Mentorship Platform with AI Matching

A full-stack web application where users offer skills, find mentors, request
short micro-mentorship sessions, and get AI-powered match recommendations.
Built as a final-year CSE project.

---

## 1. Tech Stack

| Layer     | Technology                                             |
|-----------|---------------------------------------------------------|
| Frontend  | HTML5, CSS3, Vanilla JavaScript (responsive, no framework) |
| Backend   | Java 17, Spring Boot 3, Spring MVC, Maven                |
| Database  | MySQL 8, raw JDBC (`java.sql.PreparedStatement`) — **no JPA/Hibernate** |
| AI Engine | Custom explainable rule-based matching algorithm (Java) |

---

## 2. Project Structure

```
skill-exchange-platform/
├── database/
│   ├── schema.sql          # CREATE TABLE statements, keys, constraints
│   └── sample_data.sql     # Demo users, skills, requests, sessions, ratings
│
├── backend/                          (Spring Boot / Maven project)
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/skillexchange/
│       │   ├── SkillExchangeApplication.java
│       │   ├── config/        # DataSource (JDBC/HikariCP), CORS, exception handler
│       │   ├── controller/    # REST controllers (one per module)
│       │   ├── service/       # Business logic incl. the AI MatchingService
│       │   ├── repository/    # Raw JDBC data access (PreparedStatements)
│       │   ├── model/         # POJOs mapped to DB tables
│       │   ├── dto/           # Request/response payload objects
│       │   └── util/          # PasswordUtil, ValidationUtil, TokenUtil
│       └── resources/
│           └── application.properties
│
└── frontend/                         (static HTML/CSS/JS - no build step)
    ├── index.html               (Landing page)
    ├── register.html
    ├── login.html
    ├── dashboard.html
    ├── profile.html
    ├── skills.html
    ├── find-mentors.html
    ├── ai-recommendations.html
    ├── mentor-details.html
    ├── requests.html
    ├── schedule-session.html
    ├── sessions.html
    ├── ratings.html
    ├── css/style.css
    └── js/
        ├── api.js    (central REST API client)
        └── nav.js    (shared navbar)
```

---

## 3. Database Setup (MySQL)

1. Make sure MySQL Server (8.x recommended) is installed and running.
2. Open a terminal / MySQL client and run:

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/sample_data.sql
```

This creates the `skill_exchange_db` database with all tables
(`users`, `profiles`, `skills`, `user_skills`, `availability`,
`mentorship_requests`, `matches`, `sessions`, `ratings`) plus demo data
(6 sample users, 15 skills, sample requests/sessions/ratings).

**Demo login:** `arjun@example.com` / `password123` (same password for all
seeded demo users — see `database/sample_data.sql` for the full list of
emails).

---

## 4. Backend Setup (Spring Boot)

### 4.1 Configure the database connection

Edit `backend/src/main/resources/application.properties` if your MySQL
credentials differ from the defaults:

```properties
db.url=jdbc:mysql://localhost:3306/skill_exchange_db?useSSL=false&serverTimezone=UTC
db.username=root
db.password=root
```

### 4.2 Run with Maven (command line)

```bash
cd backend
mvn spring-boot:run
```

### 4.3 Run in IntelliJ IDEA

1. `File → Open` → select the `backend/` folder (IntelliJ will detect the
   Maven project via `pom.xml` and download dependencies automatically).
2. Wait for Maven indexing to finish.
3. Open `SkillExchangeApplication.java` and click the green ▶ Run button.
4. Confirm the console shows:
   ```
   Skill Exchange Platform backend started!
   API base URL: http://localhost:8080/api
   ```

### 4.4 Run in VS Code

1. Install the **Extension Pack for Java** and **Spring Boot Extension Pack**.
2. `File → Open Folder` → select `backend/`.
3. Open `SkillExchangeApplication.java`, click **Run** above the `main` method
   (or use `mvn spring-boot:run` in the integrated terminal).

The backend starts on **http://localhost:8080**. All REST endpoints are
under `/api/...` (see `API_DOCUMENTATION.md`).

---

## 5. Frontend Setup

The frontend is plain HTML/CSS/JS — no build tools, no npm required.

### Option A — VS Code Live Server (recommended)
1. Open the `frontend/` folder in VS Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` → **Open with Live Server**.
4. It will open at something like `http://localhost:5500`.

### Option B — Open directly in browser
Just double-click `frontend/index.html`. (CORS is configured to allow this,
but Live Server is smoother because of relative link navigation.)

> Make sure the backend is running on port 8080 first — `js/api.js` points
> to `http://localhost:8080/api` by default. Change `API_BASE_URL` at the
> top of `frontend/js/api.js` if you deploy the backend elsewhere.

---

## 6. Full Demo Flow

1. Open `index.html` → **Get Started Free** → Register a new account.
2. You're redirected to **Profile** — fill in bio, interests, and learning
   goals, then save.
3. Go to **Skills** → add a few skills you can *teach* (OFFERED) and a few
   you want to *learn* (WANTED), with proficiency levels.
4. Go to **AI Matches** — the matching engine scores every other user and
   shows ranked recommendations with a plain-English explanation.
5. Click **Request Mentorship** on a match → pick a skill → send.
6. Log in as that matched user (or use a seeded demo account) → go to
   **Requests → Received** → **Accept**.
7. Back on the sender's account → **Requests → Sent** → **Schedule Session**
   → pick date/time/duration (15/30/45/60 min).
8. On **My Sessions**, mark the session **Completed** once it's done.
9. Click **Give Feedback** → choose 1–5 stars + write feedback → submit.
10. Check the **Dashboard** — profile completion, matches, requests,
    sessions, and average rating all update live from the database.

---

## 7. AI Matching Algorithm (Summary)

Implemented in `backend/.../service/MatchingService.java`. For each
candidate user it computes:

| Component                | Weight | What it measures |
|---------------------------|--------|-------------------|
| Skill Compatibility       | 50%    | How many of *your* wanted skills the candidate *offers*, plus a mutual-exchange bonus |
| Learning Goal Compatibility | 20%  | Overlap between your free-text learning goals and their offered skills |
| Interest Compatibility    | 15%    | Jaccard similarity between your interest tags and theirs |
| Skill Level Compatibility | 10%    | Whether their proficiency is a good "mentor gap" above yours |
| Availability Compatibility| 5%     | Whether your weekly free time-slots overlap |

`Overall Match = Σ (component score × weight)`, rounded to 2 decimals.
Every match also returns a `reason` string such as:

> "Recommended because Arjun Mehta offers Java, Spring Boot, which match
> your learning goals. Their experience level is well-suited to mentor you."

This makes the AI **explainable** — the score is never a black box.

---

## 8. Security Notes (student-project scope)

- Passwords are stored as salted SHA-256 hashes (`PasswordUtil`), never in
  plain text. A production system should upgrade to BCrypt/Argon2.
- Authentication uses simple in-memory session tokens (`AuthService`)
  instead of full Spring Security/JWT, to keep the project easy to run and
  explain in a viva/demo.
- All SQL queries use `PreparedStatement` parameter binding — no string
  concatenation — to prevent SQL injection.
- CORS is open (`*`) for local development; restrict `CorsConfig` before
  any real deployment.

---

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| `Cannot reach the server` in the browser | Make sure the Spring Boot app is running on port 8080 |
| `Communications link failure` in backend logs | MySQL isn't running, or `db.url`/credentials in `application.properties` are wrong |
| `Unknown database 'skill_exchange_db'` | Run `database/schema.sql` first |
| CORS errors in browser console | Confirm `CorsConfig.java` is present and the backend was restarted after any edits |
| Port 8080 already in use | Change `server.port` in `application.properties` **and** `API_BASE_URL` in `frontend/js/api.js` |

---

## 10. API Documentation

See `API_DOCUMENTATION.md` for the full list of REST endpoints, request/response
shapes, and example payloads.
