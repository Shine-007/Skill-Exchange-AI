package com.example.skillexchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Skill Exchange & Micro-Mentorship Platform backend.
 * Run this class (or `mvn spring-boot:run`) to start the embedded Tomcat server
 * on port 8080. Make sure MySQL is running and the schema has been created
 * (see /database/schema.sql) before starting the app.
 */
@SpringBootApplication
public class SkillExchangeApplication {
    public static void main(String[] args) {
        SpringApplication.run(SkillExchangeApplication.class, args);
        System.out.println("=================================================");
        System.out.println(" Skill Exchange Platform backend started!");
        System.out.println(" API base URL: http://localhost:8080/api");
        System.out.println("=================================================");
    }
}
