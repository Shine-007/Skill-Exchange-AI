package com.example.skillexchange.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Manually configures the JDBC DataSource used by all Repository classes.
 * We intentionally avoid Spring Data JPA / Hibernate here — every repository
 * uses raw java.sql.PreparedStatement so the SQL is fully visible and
 * explainable (required for the "no JPA/Hibernate" project rule).
 */
@Configuration
public class DatabaseConfig {

    @Value("${db.url}")
    private String url;

    @Value("${db.username}")
    private String username;

    @Value("${db.password}")
    private String password;

    @Value("${db.driver}")
    private String driver;

    @Value("${db.pool.maximumPoolSize:10}")
    private int maxPoolSize;

    @Value("${db.pool.minimumIdle:2}")
    private int minIdle;

    @Value("${db.pool.connectionTimeout:30000}")
    private long connectionTimeout;

    @Bean
    public DataSource dataSource() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setUsername(username);
        config.setPassword(password);
        config.setDriverClassName(driver);
        config.setMaximumPoolSize(maxPoolSize);
        config.setMinimumIdle(minIdle);
        config.setConnectionTimeout(connectionTimeout);
        config.setPoolName("SkillExchangeHikariPool");
        return new HikariDataSource(config);
    }
}
