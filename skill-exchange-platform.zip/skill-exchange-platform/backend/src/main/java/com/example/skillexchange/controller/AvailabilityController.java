package com.example.skillexchange.controller;

import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.model.Availability;
import com.example.skillexchange.repository.AvailabilityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;
import java.util.List;
import java.util.Map;

/**
 * POST /api/availability          - add a weekly free time-slot
 * GET  /api/availability/{userId} - list a user's availability
 */
@RestController
@RequestMapping("/api/availability")
public class AvailabilityController {

    @Autowired private AvailabilityRepository availabilityRepository;

    @PostMapping
    public ResponseEntity<ApiResponse<Availability>> add(@RequestBody Map<String, String> body) {
        try {
            Availability a = new Availability();
            a.setUserId(Long.parseLong(body.get("userId")));
            a.setDayOfWeek(body.get("dayOfWeek").toUpperCase());
            a.setStartTime(Time.valueOf(body.get("startTime") + ":00"));
            a.setEndTime(Time.valueOf(body.get("endTime") + ":00"));
            return ResponseEntity.ok(ApiResponse.ok("Availability added", availabilityRepository.save(a)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail("Invalid availability data: " + e.getMessage()));
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<Availability>>> list(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Availability fetched", availabilityRepository.findByUserId(userId)));
    }
}
