package com.example.skillexchange.controller;

import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.dto.MatchDto;
import com.example.skillexchange.service.MatchingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** GET /api/matches/{userId} - the AI matching engine endpoint. */
@RestController
@RequestMapping("/api/matches")
public class MatchController {

    @Autowired private MatchingService matchingService;

    @GetMapping("/{userId}")
    public org.springframework.http.ResponseEntity<ApiResponse<List<MatchDto>>> getMatches(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "10") int limit) {
        List<MatchDto> matches = matchingService.findMatchesForUser(userId, limit);
        return org.springframework.http.ResponseEntity.ok(ApiResponse.ok("AI recommendations generated", matches));
    }
}
