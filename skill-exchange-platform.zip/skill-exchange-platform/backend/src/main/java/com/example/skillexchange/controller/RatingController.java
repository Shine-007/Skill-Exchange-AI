package com.example.skillexchange.controller;

import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.dto.RatingCreateDto;
import com.example.skillexchange.model.Rating;
import com.example.skillexchange.service.RatingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * POST /api/ratings          - submit a 1-5 star rating + feedback after a session
 * GET  /api/ratings/{userId} - list ratings received by this user
 */
@RestController
@RequestMapping("/api/ratings")
public class RatingController {

    @Autowired private RatingService ratingService;

    @PostMapping
    public ResponseEntity<ApiResponse<Rating>> submit(@Valid @RequestBody RatingCreateDto dto) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Rating submitted", ratingService.submitRating(dto)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<Rating>>> list(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Ratings fetched", ratingService.getRatingsForUser(userId)));
    }

    @GetMapping("/{userId}/summary")
    public ResponseEntity<ApiResponse<Map<String, Object>>> summary(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Rating summary fetched", ratingService.getRatingSummary(userId)));
    }
}
