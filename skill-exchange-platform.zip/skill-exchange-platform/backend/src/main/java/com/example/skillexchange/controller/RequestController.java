package com.example.skillexchange.controller;

import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.dto.RequestCreateDto;
import com.example.skillexchange.dto.RequestStatusUpdateDto;
import com.example.skillexchange.model.MentorshipRequest;
import com.example.skillexchange.service.RequestService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * POST /api/requests          - send a mentorship request
 * GET  /api/requests/{userId} - list requests involving this user
 * PUT  /api/requests/{id}     - accept / reject / cancel
 */
@RestController
@RequestMapping("/api/requests")
public class RequestController {

    @Autowired private RequestService requestService;

    @PostMapping
    public ResponseEntity<ApiResponse<MentorshipRequest>> send(@Valid @RequestBody RequestCreateDto dto) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Mentorship request sent", requestService.sendRequest(dto)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<MentorshipRequest>>> list(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Requests fetched", requestService.getRequestsForUser(userId)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<MentorshipRequest>> updateStatus(@PathVariable Long id, @Valid @RequestBody RequestStatusUpdateDto dto) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Request updated", requestService.updateStatus(id, dto.getStatus())));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }
}
