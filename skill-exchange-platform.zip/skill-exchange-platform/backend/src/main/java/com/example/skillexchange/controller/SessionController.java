package com.example.skillexchange.controller;

import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.dto.SessionCreateDto;
import com.example.skillexchange.model.Session;
import com.example.skillexchange.service.SessionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * POST /api/sessions              - schedule a session from an accepted request
 * GET  /api/sessions/{userId}     - list sessions for this user
 * PUT  /api/sessions/{id}/complete
 * PUT  /api/sessions/{id}/cancel
 */
@RestController
@RequestMapping("/api/sessions")
public class SessionController {

    @Autowired private SessionService sessionService;

    @PostMapping
    public ResponseEntity<ApiResponse<Session>> schedule(@Valid @RequestBody SessionCreateDto dto) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Session scheduled", sessionService.scheduleSession(dto)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<List<Session>>> list(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Sessions fetched", sessionService.getSessionsForUser(userId)));
    }

    @PutMapping("/{id}/complete")
    public ResponseEntity<ApiResponse<Session>> complete(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Session marked completed", sessionService.completeSession(id)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse<Session>> cancel(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Session cancelled", sessionService.cancelSession(id)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }
}
