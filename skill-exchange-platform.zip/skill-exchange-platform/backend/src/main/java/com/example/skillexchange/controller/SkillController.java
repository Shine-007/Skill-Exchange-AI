package com.example.skillexchange.controller;

import com.example.skillexchange.dto.AddSkillRequest;
import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.model.Skill;
import com.example.skillexchange.model.UserSkill;
import com.example.skillexchange.service.SkillService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * GET/POST /api/skills            - master skill catalog
 * POST/GET/DELETE /api/skills/user - per-user skill management
 * GET /api/skills/search           - find mentors offering a skill (search & discovery)
 */
@RestController
@RequestMapping("/api/skills")
public class SkillController {

    @Autowired private SkillService skillService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Skill>>> getAllSkills() {
        return ResponseEntity.ok(ApiResponse.ok("Skills fetched", skillService.getAllSkills()));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<Skill>> addSkillToCatalog(@RequestBody Map<String, String> body) {
        try {
            String name = body.get("skillName");
            String category = body.getOrDefault("category", "General");
            if (name == null || name.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(ApiResponse.fail("skillName is required"));
            }
            return ResponseEntity.ok(ApiResponse.ok("Skill added", skillService.addSkillToCatalog(name, category)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @PostMapping("/user")
    public ResponseEntity<ApiResponse<UserSkill>> addUserSkill(@Valid @RequestBody AddSkillRequest request) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Skill added to profile", skillService.addUserSkill(request)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse<List<UserSkill>>> getUserSkills(@PathVariable Long userId,
                                                                       @RequestParam(required = false) String type) {
        return ResponseEntity.ok(ApiResponse.ok("User skills fetched", skillService.getUserSkills(userId, type)));
    }

    @DeleteMapping("/user/{userSkillId}")
    public ResponseEntity<ApiResponse<Void>> removeUserSkill(@PathVariable Long userSkillId, @RequestParam Long userId) {
        skillService.removeUserSkill(userSkillId, userId);
        return ResponseEntity.ok(ApiResponse.ok("Skill removed", null));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> searchMentors(@RequestParam String skillName,
                                                                                  @RequestParam(required = false) String proficiency) {
        return ResponseEntity.ok(ApiResponse.ok("Search results", skillService.searchMentorsBySkill(skillName, proficiency)));
    }
}
