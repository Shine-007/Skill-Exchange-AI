package com.example.skillexchange.controller;

import com.example.skillexchange.dto.ApiResponse;
import com.example.skillexchange.dto.DashboardDto;
import com.example.skillexchange.dto.ProfileUpdateRequest;
import com.example.skillexchange.dto.UserProfileDto;
import com.example.skillexchange.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/** GET/PUT /api/users/{id}, GET /api/users/{id}/dashboard */
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired private UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<UserProfileDto>> getUser(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Profile fetched", userService.getFullProfile(id)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.fail(e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<UserProfileDto>> updateUser(@PathVariable Long id, @RequestBody ProfileUpdateRequest request) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Profile updated", userService.updateProfile(id, request)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ApiResponse.fail(e.getMessage()));
        }
    }

    @GetMapping("/{id}/dashboard")
    public ResponseEntity<ApiResponse<DashboardDto>> getDashboard(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(ApiResponse.ok("Dashboard fetched", userService.getDashboard(id)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.fail(e.getMessage()));
        }
    }
}
