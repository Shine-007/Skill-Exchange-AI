package com.example.skillexchange.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/** Payload for POST /api/skills/user - attach a skill to the logged-in user. */
public class AddSkillRequest {
    @NotNull(message = "userId is required")
    private Long userId;

    @NotBlank(message = "skillName is required")
    private String skillName;

    private String category = "General";

    @NotBlank(message = "type is required (OFFERED or WANTED)")
    private String type; // OFFERED / WANTED

    private String proficiency = "BEGINNER";

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getSkillName() { return skillName; }
    public void setSkillName(String skillName) { this.skillName = skillName; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getProficiency() { return proficiency; }
    public void setProficiency(String proficiency) { this.proficiency = proficiency; }
}
