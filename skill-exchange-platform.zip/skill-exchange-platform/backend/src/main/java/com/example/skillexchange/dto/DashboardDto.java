package com.example.skillexchange.dto;

import com.example.skillexchange.model.MentorshipRequest;
import com.example.skillexchange.model.Session;
import com.example.skillexchange.model.UserSkill;
import java.util.List;

/** Aggregated data returned by GET /api/users/{id}/dashboard */
public class DashboardDto {
    private int profileCompletion;
    private List<UserSkill> skillsOffered;
    private List<UserSkill> skillsWanted;
    private List<MatchDto> topMatches;
    private List<MentorshipRequest> pendingRequests;
    private List<Session> upcomingSessions;
    private List<Session> completedSessions;
    private double averageRating;
    private int totalRatings;

    public int getProfileCompletion() { return profileCompletion; }
    public void setProfileCompletion(int profileCompletion) { this.profileCompletion = profileCompletion; }
    public List<UserSkill> getSkillsOffered() { return skillsOffered; }
    public void setSkillsOffered(List<UserSkill> skillsOffered) { this.skillsOffered = skillsOffered; }
    public List<UserSkill> getSkillsWanted() { return skillsWanted; }
    public void setSkillsWanted(List<UserSkill> skillsWanted) { this.skillsWanted = skillsWanted; }
    public List<MatchDto> getTopMatches() { return topMatches; }
    public void setTopMatches(List<MatchDto> topMatches) { this.topMatches = topMatches; }
    public List<MentorshipRequest> getPendingRequests() { return pendingRequests; }
    public void setPendingRequests(List<MentorshipRequest> pendingRequests) { this.pendingRequests = pendingRequests; }
    public List<Session> getUpcomingSessions() { return upcomingSessions; }
    public void setUpcomingSessions(List<Session> upcomingSessions) { this.upcomingSessions = upcomingSessions; }
    public List<Session> getCompletedSessions() { return completedSessions; }
    public void setCompletedSessions(List<Session> completedSessions) { this.completedSessions = completedSessions; }
    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }
    public int getTotalRatings() { return totalRatings; }
    public void setTotalRatings(int totalRatings) { this.totalRatings = totalRatings; }
}
