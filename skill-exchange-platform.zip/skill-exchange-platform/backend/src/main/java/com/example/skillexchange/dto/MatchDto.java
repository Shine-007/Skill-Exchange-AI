package com.example.skillexchange.dto;

import java.util.List;

/**
 * Result of the AI matching engine for a single candidate match.
 * Contains the overall score plus the individual component scores and
 * a human-readable explanation - this is what makes the matching
 * "explainable" rather than a black box.
 */
public class MatchDto {
    private Long matchedUserId;
    private String matchedUserName;
    private String matchedUserPhoto;
    private double averageRating;

    private double skillMatch;        // 0-100, weight 50%
    private double goalMatch;         // 0-100, weight 20%
    private double interestMatch;     // 0-100, weight 15%
    private double levelMatch;        // 0-100, weight 10%
    private double availabilityMatch; // 0-100, weight 5%
    private double overallMatch;      // weighted sum, 0-100

    private List<String> matchingSkills;  // skills that overlap (their OFFERED vs my WANTED)
    private String reason;                // explanation sentence

    public Long getMatchedUserId() { return matchedUserId; }
    public void setMatchedUserId(Long matchedUserId) { this.matchedUserId = matchedUserId; }
    public String getMatchedUserName() { return matchedUserName; }
    public void setMatchedUserName(String matchedUserName) { this.matchedUserName = matchedUserName; }
    public String getMatchedUserPhoto() { return matchedUserPhoto; }
    public void setMatchedUserPhoto(String matchedUserPhoto) { this.matchedUserPhoto = matchedUserPhoto; }
    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }
    public double getSkillMatch() { return skillMatch; }
    public void setSkillMatch(double skillMatch) { this.skillMatch = skillMatch; }
    public double getGoalMatch() { return goalMatch; }
    public void setGoalMatch(double goalMatch) { this.goalMatch = goalMatch; }
    public double getInterestMatch() { return interestMatch; }
    public void setInterestMatch(double interestMatch) { this.interestMatch = interestMatch; }
    public double getLevelMatch() { return levelMatch; }
    public void setLevelMatch(double levelMatch) { this.levelMatch = levelMatch; }
    public double getAvailabilityMatch() { return availabilityMatch; }
    public void setAvailabilityMatch(double availabilityMatch) { this.availabilityMatch = availabilityMatch; }
    public double getOverallMatch() { return overallMatch; }
    public void setOverallMatch(double overallMatch) { this.overallMatch = overallMatch; }
    public List<String> getMatchingSkills() { return matchingSkills; }
    public void setMatchingSkills(List<String> matchingSkills) { this.matchingSkills = matchingSkills; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}
