package com.example.skillexchange.dto;

/** Payload for PUT /api/users/{id} - updates profile fields. */
public class ProfileUpdateRequest {
    private String name;
    private String photoUrl;
    private String bio;
    private String interests;       // comma-separated
    private String learningGoals;   // comma-separated
    private String preferredMentorshipType; // ONLINE, IN_PERSON, BOTH

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getInterests() { return interests; }
    public void setInterests(String interests) { this.interests = interests; }
    public String getLearningGoals() { return learningGoals; }
    public void setLearningGoals(String learningGoals) { this.learningGoals = learningGoals; }
    public String getPreferredMentorshipType() { return preferredMentorshipType; }
    public void setPreferredMentorshipType(String preferredMentorshipType) { this.preferredMentorshipType = preferredMentorshipType; }
}
