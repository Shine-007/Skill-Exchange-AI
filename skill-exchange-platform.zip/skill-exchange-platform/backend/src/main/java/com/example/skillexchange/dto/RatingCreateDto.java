package com.example.skillexchange.dto;

import jakarta.validation.constraints.NotNull;

/** Payload for POST /api/ratings */
public class RatingCreateDto {
    @NotNull(message = "sessionId is required")
    private Long sessionId;

    @NotNull(message = "raterId is required")
    private Long raterId;

    @NotNull(message = "ratedUserId is required")
    private Long ratedUserId;

    @NotNull(message = "stars is required (1-5)")
    private Integer stars;

    private String feedback;

    public Long getSessionId() { return sessionId; }
    public void setSessionId(Long sessionId) { this.sessionId = sessionId; }
    public Long getRaterId() { return raterId; }
    public void setRaterId(Long raterId) { this.raterId = raterId; }
    public Long getRatedUserId() { return ratedUserId; }
    public void setRatedUserId(Long ratedUserId) { this.ratedUserId = ratedUserId; }
    public Integer getStars() { return stars; }
    public void setStars(Integer stars) { this.stars = stars; }
    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }
}
