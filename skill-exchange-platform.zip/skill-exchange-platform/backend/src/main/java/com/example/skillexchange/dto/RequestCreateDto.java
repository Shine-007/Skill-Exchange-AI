package com.example.skillexchange.dto;

import jakarta.validation.constraints.NotNull;

/** Payload for POST /api/requests */
public class RequestCreateDto {
    @NotNull(message = "senderId is required")
    private Long senderId;

    @NotNull(message = "receiverId is required")
    private Long receiverId;

    @NotNull(message = "skillId is required")
    private Long skillId;

    private String message;

    public Long getSenderId() { return senderId; }
    public void setSenderId(Long senderId) { this.senderId = senderId; }
    public Long getReceiverId() { return receiverId; }
    public void setReceiverId(Long receiverId) { this.receiverId = receiverId; }
    public Long getSkillId() { return skillId; }
    public void setSkillId(Long skillId) { this.skillId = skillId; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
