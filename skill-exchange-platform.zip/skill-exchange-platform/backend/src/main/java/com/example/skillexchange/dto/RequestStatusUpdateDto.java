package com.example.skillexchange.dto;

import jakarta.validation.constraints.NotBlank;

/** Payload for PUT /api/requests/{id} */
public class RequestStatusUpdateDto {
    @NotBlank(message = "status is required")
    private String status; // ACCEPTED, REJECTED, CANCELLED

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
