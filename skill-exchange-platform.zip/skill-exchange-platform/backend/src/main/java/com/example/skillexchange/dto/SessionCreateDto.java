package com.example.skillexchange.dto;

import jakarta.validation.constraints.NotNull;

/** Payload for POST /api/sessions - schedule a micro-mentorship session. */
public class SessionCreateDto {
    @NotNull(message = "requestId is required")
    private Long requestId;

    @NotNull(message = "sessionDate is required (yyyy-MM-dd)")
    private String sessionDate;

    @NotNull(message = "startTime is required (HH:mm)")
    private String startTime;

    @NotNull(message = "durationMinutes is required (15/30/45/60)")
    private Integer durationMinutes;

    private String notes;

    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }
    public String getSessionDate() { return sessionDate; }
    public void setSessionDate(String sessionDate) { this.sessionDate = sessionDate; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public Integer getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(Integer durationMinutes) { this.durationMinutes = durationMinutes; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
