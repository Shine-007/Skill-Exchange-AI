package com.example.skillexchange.dto;

import com.example.skillexchange.model.UserSkill;
import java.util.List;

/** Full profile view returned by GET /api/users/{id}. */
public class UserProfileDto {
    private Long userId;
    private String name;
    private String email;
    private String photoUrl;
    private String bio;
    private String interests;
    private String learningGoals;
    private String preferredMentorshipType;
    private int profileCompletion;
    private double averageRating;
    private int totalRatings;
    private List<UserSkill> skillsOffered;
    private List<UserSkill> skillsWanted;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getInterests() { return interests; }
    public void setInterests(String interests) { this.interests = interests; }
    public String getLearningGoals() { return learningGoals; }
    public void setLearningGoals(String learningGoals) { this.learningGoals = learningGoals; }
    public String getPreferredMentorshipType() { return preferredMentorshipType; }
    public void setPreferredMentorshipType(String preferredMentorshipType) { this.preferredMentorshipType = preferredMentorshipType; }
    public int getProfileCompletion() { return profileCompletion; }
    public void setProfileCompletion(int profileCompletion) { this.profileCompletion = profileCompletion; }
    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }
    public int getTotalRatings() { return totalRatings; }
    public void setTotalRatings(int totalRatings) { this.totalRatings = totalRatings; }
    public List<UserSkill> getSkillsOffered() { return skillsOffered; }
    public void setSkillsOffered(List<UserSkill> skillsOffered) { this.skillsOffered = skillsOffered; }
    public List<UserSkill> getSkillsWanted() { return skillsWanted; }
    public void setSkillsWanted(List<UserSkill> skillsWanted) { this.skillsWanted = skillsWanted; }
}
