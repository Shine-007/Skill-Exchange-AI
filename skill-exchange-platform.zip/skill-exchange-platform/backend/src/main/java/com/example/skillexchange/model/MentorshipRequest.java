package com.example.skillexchange.model;

import java.sql.Timestamp;

/** Maps to the `mentorship_requests` table. */
public class MentorshipRequest {
    private Long requestId;
    private Long senderId;
    private String senderName;    // joined convenience field
    private Long receiverId;
    private String receiverName;  // joined convenience field
    private Long skillId;
    private String skillName;     // joined convenience field
    private String message;
    private String status; // PENDING, ACCEPTED, REJECTED, CANCELLED
    private Timestamp createdAt;

    public MentorshipRequest() {}

    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }
    public Long getSenderId() { return senderId; }
    public void setSenderId(Long senderId) { this.senderId = senderId; }
    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }
    public Long getReceiverId() { return receiverId; }
    public void setReceiverId(Long receiverId) { this.receiverId = receiverId; }
    public String getReceiverName() { return receiverName; }
    public void setReceiverName(String receiverName) { this.receiverName = receiverName; }
    public Long getSkillId() { return skillId; }
    public void setSkillId(Long skillId) { this.skillId = skillId; }
    public String getSkillName() { return skillName; }
    public void setSkillName(String skillName) { this.skillName = skillName; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
