package com.example.skillexchange.model;

/** Maps to the `profiles` table. */
public class Profile {
    private Long profileId;
    private Long userId;
    private String photoUrl;
    private String bio;
    private String interests;        // comma-separated
    private String learningGoals;    // comma-separated
    private String preferredMentorshipType; // ONLINE, IN_PERSON, BOTH
    private int profileCompletion;

    public Profile() {}

    public Long getProfileId() { return profileId; }
    public void setProfileId(Long profileId) { this.profileId = profileId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getInterests() { return interests; }
    public void setInterests(String interests) { this.interests = interests; }
    public String getLearningGoals() { return learningGoals; }
    public void setLearningGoals(String learningGoals) { this.learningGoals = learningGoals; }
    public String getPreferredMentorshipType() { return preferredMentorshipType; }
    public void setPreferredMentorshipType(String preferredMentorshipType) { this.preferredMentorshipType = preferredMentorshipType; }
    public int getProfileCompletion() { return profileCompletion; }
    public void setProfileCompletion(int profileCompletion) { this.profileCompletion = profileCompletion; }
}
