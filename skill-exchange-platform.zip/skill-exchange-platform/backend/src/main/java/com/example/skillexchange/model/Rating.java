package com.example.skillexchange.model;

import java.sql.Timestamp;

/** Maps to the `ratings` table. */
public class Rating {
    private Long ratingId;
    private Long sessionId;
    private Long raterId;
    private String raterName;    // joined convenience field
    private Long ratedUserId;
    private int stars;
    private String feedback;
    private Timestamp createdAt;

    public Rating() {}

    public Long getRatingId() { return ratingId; }
    public void setRatingId(Long ratingId) { this.ratingId = ratingId; }
    public Long getSessionId() { return sessionId; }
    public void setSessionId(Long sessionId) { this.sessionId = sessionId; }
    public Long getRaterId() { return raterId; }
    public void setRaterId(Long raterId) { this.raterId = raterId; }
    public String getRaterName() { return raterName; }
    public void setRaterName(String raterName) { this.raterName = raterName; }
    public Long getRatedUserId() { return ratedUserId; }
    public void setRatedUserId(Long ratedUserId) { this.ratedUserId = ratedUserId; }
    public int getStars() { return stars; }
    public void setStars(int stars) { this.stars = stars; }
    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}
