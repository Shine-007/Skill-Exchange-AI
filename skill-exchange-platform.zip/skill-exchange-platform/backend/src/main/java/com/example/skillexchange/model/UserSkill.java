package com.example.skillexchange.model;

/** Maps to the `user_skills` table - links a user to a skill they offer or want. */
public class UserSkill {
    private Long userSkillId;
    private Long userId;
    private Long skillId;
    private String skillName;   // populated on joined reads for convenience
    private String type;        // OFFERED / WANTED
    private String proficiency; // BEGINNER / INTERMEDIATE / ADVANCED / EXPERT

    public UserSkill() {}

    public Long getUserSkillId() { return userSkillId; }
    public void setUserSkillId(Long userSkillId) { this.userSkillId = userSkillId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getSkillId() { return skillId; }
    public void setSkillId(Long skillId) { this.skillId = skillId; }
    public String getSkillName() { return skillName; }
    public void setSkillName(String skillName) { this.skillName = skillName; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getProficiency() { return proficiency; }
    public void setProficiency(String proficiency) { this.proficiency = proficiency; }
}
