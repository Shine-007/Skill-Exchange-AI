package com.example.skillexchange.repository;

import com.example.skillexchange.model.Availability;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** JDBC access for the `availability` table. */
@Repository
public class AvailabilityRepository {

    @Autowired
    private DataSource dataSource;

    public Availability save(Availability a) {
        String sql = "INSERT INTO availability (user_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, a.getUserId());
            ps.setString(2, a.getDayOfWeek());
            ps.setTime(3, a.getStartTime());
            ps.setTime(4, a.getEndTime());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) a.setAvailabilityId(rs.getLong(1));
            }
            return a;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving availability: " + e.getMessage(), e);
        }
    }

    public List<Availability> findByUserId(Long userId) {
        String sql = "SELECT * FROM availability WHERE user_id = ?";
        List<Availability> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error finding availability: " + e.getMessage(), e);
        }
    }

    public void deleteByUserId(Long userId) {
        String sql = "DELETE FROM availability WHERE user_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting availability: " + e.getMessage(), e);
        }
    }

    private Availability mapRow(ResultSet rs) throws SQLException {
        Availability a = new Availability();
        a.setAvailabilityId(rs.getLong("availability_id"));
        a.setUserId(rs.getLong("user_id"));
        a.setDayOfWeek(rs.getString("day_of_week"));
        a.setStartTime(rs.getTime("start_time"));
        a.setEndTime(rs.getTime("end_time"));
        return a;
    }
}
