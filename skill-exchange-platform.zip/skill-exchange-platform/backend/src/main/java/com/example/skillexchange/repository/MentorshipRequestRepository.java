package com.example.skillexchange.repository;

import com.example.skillexchange.model.MentorshipRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** JDBC access for the `mentorship_requests` table. */
@Repository
public class MentorshipRequestRepository {

    @Autowired
    private DataSource dataSource;

    private static final String JOIN_SELECT =
        "SELECT r.*, su.name AS sender_name, ru.name AS receiver_name, sk.skill_name " +
        "FROM mentorship_requests r " +
        "JOIN users su ON r.sender_id = su.user_id " +
        "JOIN users ru ON r.receiver_id = ru.user_id " +
        "JOIN skills sk ON r.skill_id = sk.skill_id ";

    public MentorshipRequest save(MentorshipRequest req) {
        String sql = "INSERT INTO mentorship_requests (sender_id, receiver_id, skill_id, message, status) " +
                     "VALUES (?, ?, ?, ?, 'PENDING')";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, req.getSenderId());
            ps.setLong(2, req.getReceiverId());
            ps.setLong(3, req.getSkillId());
            ps.setString(4, req.getMessage());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) req.setRequestId(rs.getLong(1));
            }
            return req;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving mentorship request: " + e.getMessage(), e);
        }
    }

    public Optional<MentorshipRequest> findById(Long id) {
        String sql = JOIN_SELECT + "WHERE r.request_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Error finding request: " + e.getMessage(), e);
        }
    }

    /** All requests involving this user - sent or received. */
    public List<MentorshipRequest> findByUserId(Long userId) {
        String sql = JOIN_SELECT + "WHERE r.sender_id = ? OR r.receiver_id = ? ORDER BY r.created_at DESC";
        List<MentorshipRequest> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error listing requests: " + e.getMessage(), e);
        }
    }

    public List<MentorshipRequest> findPendingByReceiverId(Long receiverId) {
        String sql = JOIN_SELECT + "WHERE r.receiver_id = ? AND r.status = 'PENDING' ORDER BY r.created_at DESC";
        List<MentorshipRequest> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, receiverId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error listing pending requests: " + e.getMessage(), e);
        }
    }

    public void updateStatus(Long requestId, String status) {
        String sql = "UPDATE mentorship_requests SET status = ? WHERE request_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setLong(2, requestId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating request status: " + e.getMessage(), e);
        }
    }

    private MentorshipRequest mapRow(ResultSet rs) throws SQLException {
        MentorshipRequest r = new MentorshipRequest();
        r.setRequestId(rs.getLong("request_id"));
        r.setSenderId(rs.getLong("sender_id"));
        r.setSenderName(rs.getString("sender_name"));
        r.setReceiverId(rs.getLong("receiver_id"));
        r.setReceiverName(rs.getString("receiver_name"));
        r.setSkillId(rs.getLong("skill_id"));
        r.setSkillName(rs.getString("skill_name"));
        r.setMessage(rs.getString("message"));
        r.setStatus(rs.getString("status"));
        r.setCreatedAt(rs.getTimestamp("created_at"));
        return r;
    }
}
