package com.example.skillexchange.repository;

import com.example.skillexchange.model.Profile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Optional;

/** JDBC access for the `profiles` table. */
@Repository
public class ProfileRepository {

    @Autowired
    private DataSource dataSource;

    /** Creates an empty profile row automatically right after registration. */
    public Profile createEmpty(Long userId) {
        String sql = "INSERT INTO profiles (user_id, bio, interests, learning_goals, preferred_mentorship_type, profile_completion) " +
                     "VALUES (?, '', '', '', 'ONLINE', 20)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, userId);
            ps.executeUpdate();
            Profile p = new Profile();
            p.setUserId(userId);
            p.setProfileCompletion(20);
            p.setPreferredMentorshipType("ONLINE");
            return p;
        } catch (SQLException e) {
            throw new RuntimeException("Error creating profile: " + e.getMessage(), e);
        }
    }

    public Optional<Profile> findByUserId(Long userId) {
        String sql = "SELECT * FROM profiles WHERE user_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Error finding profile: " + e.getMessage(), e);
        }
    }

    public void update(Profile p) {
        String sql = "UPDATE profiles SET photo_url = ?, bio = ?, interests = ?, learning_goals = ?, " +
                     "preferred_mentorship_type = ?, profile_completion = ? WHERE user_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getPhotoUrl());
            ps.setString(2, p.getBio());
            ps.setString(3, p.getInterests());
            ps.setString(4, p.getLearningGoals());
            ps.setString(5, p.getPreferredMentorshipType());
            ps.setInt(6, p.getProfileCompletion());
            ps.setLong(7, p.getUserId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating profile: " + e.getMessage(), e);
        }
    }

    private Profile mapRow(ResultSet rs) throws SQLException {
        Profile p = new Profile();
        p.setProfileId(rs.getLong("profile_id"));
        p.setUserId(rs.getLong("user_id"));
        p.setPhotoUrl(rs.getString("photo_url"));
        p.setBio(rs.getString("bio"));
        p.setInterests(rs.getString("interests"));
        p.setLearningGoals(rs.getString("learning_goals"));
        p.setPreferredMentorshipType(rs.getString("preferred_mentorship_type"));
        p.setProfileCompletion(rs.getInt("profile_completion"));
        return p;
    }
}
