package com.example.skillexchange.repository;

import com.example.skillexchange.model.Rating;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** JDBC access for the `ratings` table. */
@Repository
public class RatingRepository {

    @Autowired
    private DataSource dataSource;

    public Rating save(Rating r) {
        String sql = "INSERT INTO ratings (session_id, rater_id, rated_user_id, stars, feedback) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, r.getSessionId());
            ps.setLong(2, r.getRaterId());
            ps.setLong(3, r.getRatedUserId());
            ps.setInt(4, r.getStars());
            ps.setString(5, r.getFeedback());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) r.setRatingId(rs.getLong(1));
            }
            return r;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving rating: " + e.getMessage(), e);
        }
    }

    public List<Rating> findByRatedUserId(Long userId) {
        String sql = "SELECT rt.*, u.name AS rater_name FROM ratings rt " +
                     "JOIN users u ON rt.rater_id = u.user_id " +
                     "WHERE rt.rated_user_id = ? ORDER BY rt.created_at DESC";
        List<Rating> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error listing ratings: " + e.getMessage(), e);
        }
    }

    /** Returns [averageRating, totalCount] for a user - used on profile & dashboard. */
    public double[] getAverageAndCount(Long userId) {
        String sql = "SELECT AVG(stars) AS avg_stars, COUNT(*) AS total FROM ratings WHERE rated_user_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    double avg = rs.getDouble("avg_stars");
                    int total = rs.getInt("total");
                    return new double[]{ total == 0 ? 0.0 : avg, total };
                }
            }
            return new double[]{0.0, 0};
        } catch (SQLException e) {
            throw new RuntimeException("Error computing average rating: " + e.getMessage(), e);
        }
    }

    public boolean existsForSessionAndRater(Long sessionId, Long raterId) {
        String sql = "SELECT COUNT(*) FROM ratings WHERE session_id = ? AND rater_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, sessionId);
            ps.setLong(2, raterId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
            return false;
        } catch (SQLException e) {
            throw new RuntimeException("Error checking rating existence: " + e.getMessage(), e);
        }
    }

    private Rating mapRow(ResultSet rs) throws SQLException {
        Rating r = new Rating();
        r.setRatingId(rs.getLong("rating_id"));
        r.setSessionId(rs.getLong("session_id"));
        r.setRaterId(rs.getLong("rater_id"));
        r.setRaterName(rs.getString("rater_name"));
        r.setRatedUserId(rs.getLong("rated_user_id"));
        r.setStars(rs.getInt("stars"));
        r.setFeedback(rs.getString("feedback"));
        r.setCreatedAt(rs.getTimestamp("created_at"));
        return r;
    }
}
