package com.example.skillexchange.repository;

import com.example.skillexchange.model.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** JDBC access for the `sessions` table (scheduled micro-mentorship sessions). */
@Repository
public class SessionRepository {

    @Autowired
    private DataSource dataSource;

    private static final String JOIN_SELECT =
        "SELECT sess.*, mu.name AS mentor_name, lu.name AS learner_name, sk.skill_name " +
        "FROM sessions sess " +
        "JOIN users mu ON sess.mentor_id = mu.user_id " +
        "JOIN users lu ON sess.learner_id = lu.user_id " +
        "JOIN skills sk ON sess.skill_id = sk.skill_id ";

    public Session save(Session s) {
        String sql = "INSERT INTO sessions (request_id, mentor_id, learner_id, skill_id, session_date, start_time, duration_minutes, status, notes) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, 'SCHEDULED', ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, s.getRequestId());
            ps.setLong(2, s.getMentorId());
            ps.setLong(3, s.getLearnerId());
            ps.setLong(4, s.getSkillId());
            ps.setDate(5, s.getSessionDate());
            ps.setTime(6, s.getStartTime());
            ps.setInt(7, s.getDurationMinutes());
            ps.setString(8, s.getNotes());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) s.setSessionId(rs.getLong(1));
            }
            return s;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving session: " + e.getMessage(), e);
        }
    }

    public Optional<Session> findById(Long id) {
        String sql = JOIN_SELECT + "WHERE sess.session_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Error finding session: " + e.getMessage(), e);
        }
    }

    public List<Session> findByUserId(Long userId) {
        String sql = JOIN_SELECT + "WHERE sess.mentor_id = ? OR sess.learner_id = ? ORDER BY sess.session_date DESC, sess.start_time DESC";
        List<Session> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error listing sessions: " + e.getMessage(), e);
        }
    }

    public List<Session> findByUserIdAndStatus(Long userId, String status) {
        String sql = JOIN_SELECT + "WHERE (sess.mentor_id = ? OR sess.learner_id = ?) AND sess.status = ? " +
                     "ORDER BY sess.session_date ASC, sess.start_time ASC";
        List<Session> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, userId);
            ps.setString(3, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error listing sessions by status: " + e.getMessage(), e);
        }
    }

    public void updateStatus(Long sessionId, String status) {
        String sql = "UPDATE sessions SET status = ? WHERE session_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setLong(2, sessionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating session status: " + e.getMessage(), e);
        }
    }

    private Session mapRow(ResultSet rs) throws SQLException {
        Session s = new Session();
        s.setSessionId(rs.getLong("session_id"));
        s.setRequestId(rs.getLong("request_id"));
        s.setMentorId(rs.getLong("mentor_id"));
        s.setMentorName(rs.getString("mentor_name"));
        s.setLearnerId(rs.getLong("learner_id"));
        s.setLearnerName(rs.getString("learner_name"));
        s.setSkillId(rs.getLong("skill_id"));
        s.setSkillName(rs.getString("skill_name"));
        s.setSessionDate(rs.getDate("session_date"));
        s.setStartTime(rs.getTime("start_time"));
        s.setDurationMinutes(rs.getInt("duration_minutes"));
        s.setStatus(rs.getString("status"));
        s.setNotes(rs.getString("notes"));
        s.setCreatedAt(rs.getTimestamp("created_at"));
        return s;
    }
}
