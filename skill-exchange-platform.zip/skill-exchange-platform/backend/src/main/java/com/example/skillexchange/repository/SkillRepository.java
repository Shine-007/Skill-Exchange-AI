package com.example.skillexchange.repository;

import com.example.skillexchange.model.Skill;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** JDBC access for the `skills` master catalog table. */
@Repository
public class SkillRepository {

    @Autowired
    private DataSource dataSource;

    public List<Skill> findAll() {
        String sql = "SELECT * FROM skills ORDER BY skill_name ASC";
        List<Skill> skills = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                skills.add(mapRow(rs));
            }
            return skills;
        } catch (SQLException e) {
            throw new RuntimeException("Error listing skills: " + e.getMessage(), e);
        }
    }

    public Optional<Skill> findByName(String name) {
        String sql = "SELECT * FROM skills WHERE skill_name = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Error finding skill by name: " + e.getMessage(), e);
        }
    }

    public Optional<Skill> findById(Long id) {
        String sql = "SELECT * FROM skills WHERE skill_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Error finding skill by id: " + e.getMessage(), e);
        }
    }

    /** Inserts a new skill into the catalog if it doesn't already exist (idempotent add). */
    public Skill save(Skill skill) {
        String sql = "INSERT INTO skills (skill_name, category) VALUES (?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, skill.getSkillName());
            ps.setString(2, skill.getCategory());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) skill.setSkillId(rs.getLong(1));
            }
            return skill;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving skill: " + e.getMessage(), e);
        }
    }

    private Skill mapRow(ResultSet rs) throws SQLException {
        Skill s = new Skill();
        s.setSkillId(rs.getLong("skill_id"));
        s.setSkillName(rs.getString("skill_name"));
        s.setCategory(rs.getString("category"));
        return s;
    }
}
