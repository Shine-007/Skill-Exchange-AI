package com.example.skillexchange.repository;

import com.example.skillexchange.model.UserSkill;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** JDBC access for the `user_skills` join table. */
@Repository
public class UserSkillRepository {

    @Autowired
    private DataSource dataSource;

    private static final String JOIN_SELECT =
        "SELECT us.user_skill_id, us.user_id, us.skill_id, s.skill_name, us.type, us.proficiency " +
        "FROM user_skills us JOIN skills s ON us.skill_id = s.skill_id ";

    public UserSkill save(UserSkill us) {
        String sql = "INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE proficiency = VALUES(proficiency)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, us.getUserId());
            ps.setLong(2, us.getSkillId());
            ps.setString(3, us.getType());
            ps.setString(4, us.getProficiency());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) us.setUserSkillId(rs.getLong(1));
            }
            return us;
        } catch (SQLException e) {
            throw new RuntimeException("Error saving user skill: " + e.getMessage(), e);
        }
    }

    public List<UserSkill> findByUserIdAndType(Long userId, String type) {
        String sql = JOIN_SELECT + "WHERE us.user_id = ? AND us.type = ?";
        List<UserSkill> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setString(2, type);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error finding user skills: " + e.getMessage(), e);
        }
    }

    public List<UserSkill> findByUserId(Long userId) {
        String sql = JOIN_SELECT + "WHERE us.user_id = ?";
        List<UserSkill> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error finding user skills: " + e.getMessage(), e);
        }
    }

    /** Finds every user who OFFERS a particular skill - used for search & discovery. */
    public List<UserSkill> findOfferingUsersBySkillName(String skillName) {
        String sql = JOIN_SELECT + "WHERE us.type = 'OFFERED' AND s.skill_name LIKE ?";
        List<UserSkill> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + skillName + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("Error searching by skill: " + e.getMessage(), e);
        }
    }

    public void delete(Long userSkillId, Long userId) {
        String sql = "DELETE FROM user_skills WHERE user_skill_id = ? AND user_id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userSkillId);
            ps.setLong(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting user skill: " + e.getMessage(), e);
        }
    }

    private UserSkill mapRow(ResultSet rs) throws SQLException {
        UserSkill us = new UserSkill();
        us.setUserSkillId(rs.getLong("user_skill_id"));
        us.setUserId(rs.getLong("user_id"));
        us.setSkillId(rs.getLong("skill_id"));
        us.setSkillName(rs.getString("skill_name"));
        us.setType(rs.getString("type"));
        us.setProficiency(rs.getString("proficiency"));
        return us;
    }
}
