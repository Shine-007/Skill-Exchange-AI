package com.example.skillexchange.service;

import com.example.skillexchange.dto.AuthResponse;
import com.example.skillexchange.dto.LoginRequest;
import com.example.skillexchange.dto.RegisterRequest;
import com.example.skillexchange.model.User;
import com.example.skillexchange.repository.ProfileRepository;
import com.example.skillexchange.repository.UserRepository;
import com.example.skillexchange.util.PasswordUtil;
import com.example.skillexchange.util.TokenUtil;
import com.example.skillexchange.util.ValidationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles registration, login and simple in-memory session-token
 * validation (logout removes the token). Suitable for a demo/college
 * project; a production system would use Spring Security + JWT.
 */
@Service
public class AuthService {

    @Autowired private UserRepository userRepository;
    @Autowired private ProfileRepository profileRepository;

    // token -> userId (in-memory session store)
    private final Map<String, Long> activeSessions = new ConcurrentHashMap<>();

    public AuthResponse register(RegisterRequest req) {
        if (!ValidationUtil.isNotEmpty(req.getName())) {
            throw new IllegalArgumentException("Name is required");
        }
        if (!ValidationUtil.isValidEmail(req.getEmail())) {
            throw new IllegalArgumentException("A valid email is required");
        }
        if (!ValidationUtil.isValidPassword(req.getPassword())) {
            throw new IllegalArgumentException("Password must be at least 6 characters");
        }
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new IllegalArgumentException("An account with this email already exists");
        }

        User user = new User();
        user.setName(req.getName().trim());
        user.setEmail(req.getEmail().trim().toLowerCase());
        user.setPasswordHash(PasswordUtil.hash(req.getPassword()));
        user.setRole("USER");
        User saved = userRepository.save(user);

        // Auto-create an empty profile so the dashboard has something to show immediately
        profileRepository.createEmpty(saved.getUserId());

        String token = TokenUtil.generateToken(saved.getUserId());
        activeSessions.put(token, saved.getUserId());

        return new AuthResponse(token, saved.getUserId(), saved.getName(), saved.getEmail());
    }

    public AuthResponse login(LoginRequest req) {
        User user = userRepository.findByEmail(req.getEmail() == null ? "" : req.getEmail().trim().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));

        if (!PasswordUtil.matches(req.getPassword(), user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password");
        }

        String token = TokenUtil.generateToken(user.getUserId());
        activeSessions.put(token, user.getUserId());

        return new AuthResponse(token, user.getUserId(), user.getName(), user.getEmail());
    }

    public void logout(String token) {
        activeSessions.remove(token);
    }

    public Long resolveUserId(String token) {
        return activeSessions.get(token);
    }
}
