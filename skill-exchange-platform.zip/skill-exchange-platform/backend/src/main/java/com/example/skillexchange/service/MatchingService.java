package com.example.skillexchange.service;

import com.example.skillexchange.dto.MatchDto;
import com.example.skillexchange.model.*;
import com.example.skillexchange.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * =====================================================================
 * AI MATCHING ENGINE
 * =====================================================================
 * This is a rule-based / content-based recommender system. It is
 * "explainable AI" in the sense that every score is a transparent,
 * human-readable calculation (not a black-box neural network) - which
 * is exactly what is required for a final-year project: the user (and
 * the examiner) can see *why* a match was recommended.
 *
 * Overall Match Score =
 *      50% Skill Compatibility        (do their offered skills match my wanted skills?)
 *    + 20% Learning Goal Compatibility (does their offering align with my stated goals?)
 *    + 15% Interest Compatibility      (overlap of interest tags)
 *    + 10% Skill Level Compatibility   (is their level appropriate to teach me?)
 *    +  5% Availability Compatibility  (do our free time-slots overlap?)
 * =====================================================================
 */
@Service
public class MatchingService {

    @Autowired private UserRepository userRepository;
    @Autowired private ProfileRepository profileRepository;
    @Autowired private UserSkillRepository userSkillRepository;
    @Autowired private AvailabilityRepository availabilityRepository;
    @Autowired private RatingRepository ratingRepository;

    // Scoring weights - kept as named constants so the algorithm stays explainable/tunable
    private static final double WEIGHT_SKILL        = 0.50;
    private static final double WEIGHT_GOAL         = 0.20;
    private static final double WEIGHT_INTEREST     = 0.15;
    private static final double WEIGHT_LEVEL        = 0.10;
    private static final double WEIGHT_AVAILABILITY = 0.05;

    // Proficiency levels ranked for numeric comparison
    private static final List<String> LEVEL_ORDER =
            Arrays.asList("BEGINNER", "INTERMEDIATE", "ADVANCED", "EXPERT");

    /**
     * Main entry point: computes ranked match recommendations for `userId`
     * against every other active user in the system.
     */
    public List<MatchDto> findMatchesForUser(Long userId, int limit) {
        Profile myProfile = profileRepository.findByUserId(userId).orElse(new Profile());
        List<UserSkill> mySkillsWanted = userSkillRepository.findByUserIdAndType(userId, "WANTED");
        List<UserSkill> mySkillsOffered = userSkillRepository.findByUserIdAndType(userId, "OFFERED");
        List<Availability> myAvailability = availabilityRepository.findByUserId(userId);

        List<User> candidates = userRepository.findAllExcept(userId);
        List<MatchDto> results = new ArrayList<>();

        for (User candidate : candidates) {
            List<UserSkill> theirSkillsOffered = userSkillRepository.findByUserIdAndType(candidate.getUserId(), "OFFERED");
            List<UserSkill> theirSkillsWanted = userSkillRepository.findByUserIdAndType(candidate.getUserId(), "WANTED");

            // Skip candidates who have nothing to offer and nothing to learn overlap-wise
            if (theirSkillsOffered.isEmpty() && theirSkillsWanted.isEmpty()) continue;

            Profile theirProfile = profileRepository.findByUserId(candidate.getUserId()).orElse(new Profile());
            List<Availability> theirAvailability = availabilityRepository.findByUserId(candidate.getUserId());

            MatchDto dto = new MatchDto();
            dto.setMatchedUserId(candidate.getUserId());
            dto.setMatchedUserName(candidate.getName());
            dto.setMatchedUserPhoto(theirProfile.getPhotoUrl());

            double[] ratingInfo = ratingRepository.getAverageAndCount(candidate.getUserId());
            dto.setAverageRating(round(ratingInfo[0]));

            // ---- 1. Skill Compatibility (50%) ----
            // How many of MY wanted skills does the candidate OFFER (and vice-versa for mutual exchange bonus)
            List<String> overlapSkills = findSkillOverlap(mySkillsWanted, theirSkillsOffered);
            double skillScore = calculateSkillScore(mySkillsWanted, theirSkillsOffered, mySkillsOffered, theirSkillsWanted);

            // ---- 2. Learning Goal Compatibility (20%) ----
            double goalScore = calculateTagOverlapScore(myProfile.getLearningGoals(), theirSkillsOffered);

            // ---- 3. Interest Compatibility (15%) ----
            double interestScore = calculateInterestScore(myProfile.getInterests(), theirProfile.getInterests());

            // ---- 4. Skill Level Compatibility (10%) ----
            double levelScore = calculateLevelScore(mySkillsWanted, theirSkillsOffered);

            // ---- 5. Availability Compatibility (5%) ----
            double availabilityScore = calculateAvailabilityScore(myAvailability, theirAvailability);

            double overall = (skillScore * WEIGHT_SKILL)
                            + (goalScore * WEIGHT_GOAL)
                            + (interestScore * WEIGHT_INTEREST)
                            + (levelScore * WEIGHT_LEVEL)
                            + (availabilityScore * WEIGHT_AVAILABILITY);

            // Candidates with literally zero skill overlap and zero goal/interest signal are not useful matches
            if (skillScore == 0 && goalScore == 0 && interestScore == 0) continue;

            dto.setSkillMatch(round(skillScore));
            dto.setGoalMatch(round(goalScore));
            dto.setInterestMatch(round(interestScore));
            dto.setLevelMatch(round(levelScore));
            dto.setAvailabilityMatch(round(availabilityScore));
            dto.setOverallMatch(round(overall));
            dto.setMatchingSkills(overlapSkills);
            dto.setReason(buildExplanation(candidate.getName(), overlapSkills, goalScore, interestScore, levelScore));

            results.add(dto);
        }

        // Rank by overall score, descending (best match first)
        results.sort((a, b) -> Double.compare(b.getOverallMatch(), a.getOverallMatch()));

        if (limit > 0 && results.size() > limit) {
            return results.subList(0, limit);
        }
        return results;
    }

    // ------------------------------------------------------------------
    // Component score calculators
    // ------------------------------------------------------------------

    /** Skills I want that they offer, PLUS a bonus for mutual/two-way exchange potential. */
    private double calculateSkillScore(List<UserSkill> myWanted, List<UserSkill> theirOffered,
                                        List<UserSkill> myOffered, List<UserSkill> theirWanted) {
        if (myWanted.isEmpty()) return 0;

        Set<Long> theirOfferedSkillIds = theirOffered.stream().map(UserSkill::getSkillId).collect(Collectors.toSet());
        long directMatches = myWanted.stream().filter(s -> theirOfferedSkillIds.contains(s.getSkillId())).count();
        double directScore = (double) directMatches / myWanted.size() * 100.0;

        // Mutual exchange bonus: they want something I offer too -> up to +10 points
        Set<Long> myOfferedSkillIds = myOffered.stream().map(UserSkill::getSkillId).collect(Collectors.toSet());
        boolean mutualExchange = theirWanted.stream().anyMatch(s -> myOfferedSkillIds.contains(s.getSkillId()));
        double bonus = mutualExchange ? 10.0 : 0.0;

        return Math.min(100.0, directScore + bonus);
    }

    private List<String> findSkillOverlap(List<UserSkill> myWanted, List<UserSkill> theirOffered) {
        Set<Long> theirOfferedIds = theirOffered.stream().map(UserSkill::getSkillId).collect(Collectors.toSet());
        return myWanted.stream()
                .filter(s -> theirOfferedIds.contains(s.getSkillId()))
                .map(UserSkill::getSkillName)
                .collect(Collectors.toList());
    }

    /** Compares my free-text learning goals against skill names the candidate offers. */
    private double calculateTagOverlapScore(String learningGoalsCsv, List<UserSkill> theirOffered) {
        List<String> goals = splitCsv(learningGoalsCsv);
        if (goals.isEmpty() || theirOffered.isEmpty()) return 0;

        long matches = 0;
        for (String goal : goals) {
            for (UserSkill skill : theirOffered) {
                if (containsIgnoreCase(goal, skill.getSkillName()) || containsIgnoreCase(skill.getSkillName(), goal)) {
                    matches++;
                    break;
                }
            }
        }
        return Math.min(100.0, ((double) matches / goals.size()) * 100.0);
    }

    /** Simple tag-overlap (Jaccard-like) similarity between two comma-separated interest lists. */
    private double calculateInterestScore(String myInterestsCsv, String theirInterestsCsv) {
        Set<String> mine = new HashSet<>(splitCsv(myInterestsCsv).stream().map(String::toLowerCase).collect(Collectors.toList()));
        Set<String> theirs = new HashSet<>(splitCsv(theirInterestsCsv).stream().map(String::toLowerCase).collect(Collectors.toList()));
        if (mine.isEmpty() || theirs.isEmpty()) return 0;

        Set<String> intersection = new HashSet<>(mine);
        intersection.retainAll(theirs);
        Set<String> union = new HashSet<>(mine);
        union.addAll(theirs);

        if (union.isEmpty()) return 0;
        return ((double) intersection.size() / union.size()) * 100.0;
    }

    /**
     * Checks whether the candidate's proficiency in the skills I want is
     * at or above intermediate - i.e. they are qualified to mentor me.
     * A candidate whose level is far above mine on skills I'm a beginner
     * at scores highest (a true "mentor" gap), while an exact level match
     * scores well for peer-to-peer exchange too.
     */
    private double calculateLevelScore(List<UserSkill> myWanted, List<UserSkill> theirOffered) {
        if (myWanted.isEmpty() || theirOffered.isEmpty()) return 0;

        Map<Long, UserSkill> theirOfferedBySkill = new HashMap<>();
        for (UserSkill s : theirOffered) theirOfferedBySkill.put(s.getSkillId(), s);

        List<Double> scores = new ArrayList<>();
        for (UserSkill want : myWanted) {
            UserSkill theirs = theirOfferedBySkill.get(want.getSkillId());
            if (theirs == null) continue;

            int myLevelIdx = LEVEL_ORDER.indexOf(want.getProficiency());
            int theirLevelIdx = LEVEL_ORDER.indexOf(theirs.getProficiency());
            if (myLevelIdx < 0) myLevelIdx = 0;
            if (theirLevelIdx < 0) theirLevelIdx = 0;

            int gap = theirLevelIdx - myLevelIdx;
            double score;
            if (gap <= 0) {
                score = 40.0; // they're at or below my level - limited mentoring value
            } else if (gap == 1) {
                score = 85.0; // one level above - ideal mentor gap
            } else {
                score = 100.0; // significantly more experienced - strong mentor
            }
            scores.add(score);
        }
        if (scores.isEmpty()) return 0;
        return scores.stream().mapToDouble(Double::doubleValue).average().orElse(0);
    }

    /** Checks if any of the two users' weekly availability windows overlap on the same day. */
    private double calculateAvailabilityScore(List<Availability> mine, List<Availability> theirs) {
        if (mine.isEmpty() || theirs.isEmpty()) return 50.0; // neutral score if not yet configured

        for (Availability a : mine) {
            for (Availability b : theirs) {
                if (a.getDayOfWeek().equals(b.getDayOfWeek())) {
                    boolean overlaps = !a.getStartTime().after(b.getEndTime()) && !b.getStartTime().after(a.getEndTime());
                    if (overlaps) return 100.0;
                }
            }
        }
        return 20.0; // no overlapping slot found
    }

    /** Builds the human-readable explanation shown to the user, e.g. on the AI Recommendations page. */
    private String buildExplanation(String candidateName, List<String> overlapSkills, double goalScore,
                                     double interestScore, double levelScore) {
        StringBuilder sb = new StringBuilder("Recommended because ");
        sb.append(candidateName);
        if (!overlapSkills.isEmpty()) {
            sb.append(" offers ").append(String.join(", ", overlapSkills));
            sb.append(overlapSkills.size() > 1 ? ", which match your learning goals." : ", which matches your learning goals.");
        } else if (goalScore > 0) {
            sb.append(" has skills aligned with your stated learning goals.");
        } else {
            sb.append(" shares similar interests with you.");
        }
        if (levelScore >= 85) {
            sb.append(" Their experience level is well-suited to mentor you.");
        }
        if (interestScore >= 40) {
            sb.append(" You also share common interests.");
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private List<String> splitCsv(String csv) {
        if (csv == null || csv.trim().isEmpty()) return Collections.emptyList();
        return Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    private boolean containsIgnoreCase(String a, String b) {
        if (a == null || b == null) return false;
        return a.toLowerCase().contains(b.toLowerCase()) || b.toLowerCase().contains(a.toLowerCase());
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
