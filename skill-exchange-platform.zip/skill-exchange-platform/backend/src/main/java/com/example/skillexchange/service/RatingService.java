package com.example.skillexchange.service;

import com.example.skillexchange.dto.RatingCreateDto;
import com.example.skillexchange.model.Rating;
import com.example.skillexchange.model.Session;
import com.example.skillexchange.repository.RatingRepository;
import com.example.skillexchange.repository.SessionRepository;
import com.example.skillexchange.util.ValidationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/** Business logic for post-session ratings & feedback. */
@Service
public class RatingService {

    @Autowired private RatingRepository ratingRepository;
    @Autowired private SessionRepository sessionRepository;

    public Rating submitRating(RatingCreateDto dto) {
        if (!ValidationUtil.isValidStarRating(dto.getStars())) {
            throw new IllegalArgumentException("stars must be between 1 and 5");
        }

        Session session = sessionRepository.findById(dto.getSessionId())
                .orElseThrow(() -> new IllegalArgumentException("Session not found"));

        if (!"COMPLETED".equals(session.getStatus())) {
            throw new IllegalArgumentException("You can only rate a completed session");
        }

        boolean isParticipant = dto.getRaterId().equals(session.getMentorId()) || dto.getRaterId().equals(session.getLearnerId());
        if (!isParticipant) {
            throw new IllegalArgumentException("Only session participants can leave a rating");
        }

        if (ratingRepository.existsForSessionAndRater(dto.getSessionId(), dto.getRaterId())) {
            throw new IllegalArgumentException("You have already rated this session");
        }

        Rating rating = new Rating();
        rating.setSessionId(dto.getSessionId());
        rating.setRaterId(dto.getRaterId());
        rating.setRatedUserId(dto.getRatedUserId());
        rating.setStars(dto.getStars());
        rating.setFeedback(dto.getFeedback());

        return ratingRepository.save(rating);
    }

    public List<Rating> getRatingsForUser(Long userId) {
        return ratingRepository.findByRatedUserId(userId);
    }

    public Map<String, Object> getRatingSummary(Long userId) {
        double[] info = ratingRepository.getAverageAndCount(userId);
        return Map.of(
                "averageRating", Math.round(info[0] * 100.0) / 100.0,
                "totalRatings", (int) info[1]
        );
    }
}
