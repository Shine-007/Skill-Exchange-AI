package com.example.skillexchange.service;

import com.example.skillexchange.dto.RequestCreateDto;
import com.example.skillexchange.model.MentorshipRequest;
import com.example.skillexchange.repository.MentorshipRequestRepository;
import com.example.skillexchange.repository.SkillRepository;
import com.example.skillexchange.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/** Business logic for sending / accepting / rejecting / cancelling mentorship requests. */
@Service
public class RequestService {

    @Autowired private MentorshipRequestRepository requestRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private SkillRepository skillRepository;

    private static final List<String> VALID_STATUSES = List.of("ACCEPTED", "REJECTED", "CANCELLED");

    public MentorshipRequest sendRequest(RequestCreateDto dto) {
        if (dto.getSenderId().equals(dto.getReceiverId())) {
            throw new IllegalArgumentException("You cannot send a mentorship request to yourself");
        }
        userRepository.findById(dto.getSenderId()).orElseThrow(() -> new IllegalArgumentException("Sender not found"));
        userRepository.findById(dto.getReceiverId()).orElseThrow(() -> new IllegalArgumentException("Receiver not found"));
        skillRepository.findById(dto.getSkillId()).orElseThrow(() -> new IllegalArgumentException("Skill not found"));

        MentorshipRequest req = new MentorshipRequest();
        req.setSenderId(dto.getSenderId());
        req.setReceiverId(dto.getReceiverId());
        req.setSkillId(dto.getSkillId());
        req.setMessage(dto.getMessage());
        return requestRepository.save(req);
    }

    public List<MentorshipRequest> getRequestsForUser(Long userId) {
        return requestRepository.findByUserId(userId);
    }

    public MentorshipRequest updateStatus(Long requestId, String status) {
        String normalized = status == null ? "" : status.toUpperCase();
        if (!VALID_STATUSES.contains(normalized)) {
            throw new IllegalArgumentException("status must be one of " + VALID_STATUSES);
        }
        MentorshipRequest existing = requestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Request not found"));
        if (!"PENDING".equals(existing.getStatus())) {
            throw new IllegalArgumentException("Only pending requests can be updated");
        }
        requestRepository.updateStatus(requestId, normalized);
        existing.setStatus(normalized);
        return existing;
    }
}
