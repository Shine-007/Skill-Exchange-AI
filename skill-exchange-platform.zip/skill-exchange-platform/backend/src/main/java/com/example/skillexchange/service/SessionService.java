package com.example.skillexchange.service;

import com.example.skillexchange.dto.SessionCreateDto;
import com.example.skillexchange.model.MentorshipRequest;
import com.example.skillexchange.model.Session;
import com.example.skillexchange.repository.MentorshipRequestRepository;
import com.example.skillexchange.repository.SessionRepository;
import com.example.skillexchange.util.ValidationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

/** Business logic for scheduling and managing micro-mentorship sessions. */
@Service
public class SessionService {

    @Autowired private SessionRepository sessionRepository;
    @Autowired private MentorshipRequestRepository requestRepository;

    public Session scheduleSession(SessionCreateDto dto) {
        if (!ValidationUtil.isValidDuration(dto.getDurationMinutes())) {
            throw new IllegalArgumentException("durationMinutes must be 15, 30, 45 or 60");
        }

        MentorshipRequest request = requestRepository.findById(dto.getRequestId())
                .orElseThrow(() -> new IllegalArgumentException("Mentorship request not found"));

        if (!"ACCEPTED".equals(request.getStatus())) {
            throw new IllegalArgumentException("A session can only be scheduled for an ACCEPTED request");
        }

        Session session = new Session();
        session.setRequestId(request.getRequestId());
        session.setMentorId(request.getReceiverId());  // receiver of the request is the mentor
        session.setLearnerId(request.getSenderId());   // sender is the learner
        session.setSkillId(request.getSkillId());
        try {
            session.setSessionDate(Date.valueOf(dto.getSessionDate()));
            session.setStartTime(Time.valueOf(dto.getStartTime() + ":00"));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("sessionDate must be yyyy-MM-dd and startTime must be HH:mm");
        }
        session.setDurationMinutes(dto.getDurationMinutes());
        session.setNotes(dto.getNotes());

        return sessionRepository.save(session);
    }

    public List<Session> getSessionsForUser(Long userId) {
        return sessionRepository.findByUserId(userId);
    }

    public Session completeSession(Long sessionId) {
        Session session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found"));
        if (!"SCHEDULED".equals(session.getStatus())) {
            throw new IllegalArgumentException("Only scheduled sessions can be marked completed");
        }
        sessionRepository.updateStatus(sessionId, "COMPLETED");
        session.setStatus("COMPLETED");
        return session;
    }

    public Session cancelSession(Long sessionId) {
        Session session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found"));
        sessionRepository.updateStatus(sessionId, "CANCELLED");
        session.setStatus("CANCELLED");
        return session;
    }
}
