package com.example.skillexchange.service;

import com.example.skillexchange.dto.AddSkillRequest;
import com.example.skillexchange.model.Skill;
import com.example.skillexchange.model.User;
import com.example.skillexchange.model.UserSkill;
import com.example.skillexchange.repository.SkillRepository;
import com.example.skillexchange.repository.UserRepository;
import com.example.skillexchange.repository.UserSkillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/** Business logic for the skill catalog and per-user skill assignment. */
@Service
public class SkillService {

    @Autowired private SkillRepository skillRepository;
    @Autowired private UserSkillRepository userSkillRepository;
    @Autowired private UserRepository userRepository;

    public List<Skill> getAllSkills() {
        return skillRepository.findAll();
    }

    public Skill addSkillToCatalog(String name, String category) {
        return skillRepository.findByName(name)
                .orElseGet(() -> skillRepository.save(new Skill(null, name.trim(), category == null ? "General" : category)));
    }

    /** Attaches a skill (offered/wanted) to a user - creates the catalog entry if it's new. */
    public UserSkill addUserSkill(AddSkillRequest req) {
        userRepository.findById(req.getUserId()).orElseThrow(() -> new IllegalArgumentException("User not found"));

        if (!"OFFERED".equalsIgnoreCase(req.getType()) && !"WANTED".equalsIgnoreCase(req.getType())) {
            throw new IllegalArgumentException("type must be OFFERED or WANTED");
        }

        Skill skill = addSkillToCatalog(req.getSkillName(), req.getCategory());

        UserSkill us = new UserSkill();
        us.setUserId(req.getUserId());
        us.setSkillId(skill.getSkillId());
        us.setType(req.getType().toUpperCase());
        us.setProficiency(req.getProficiency() == null ? "BEGINNER" : req.getProficiency().toUpperCase());
        UserSkill saved = userSkillRepository.save(us);
        saved.setSkillName(skill.getSkillName());
        return saved;
    }

    public void removeUserSkill(Long userSkillId, Long userId) {
        userSkillRepository.delete(userSkillId, userId);
    }

    public List<UserSkill> getUserSkills(Long userId, String type) {
        if (type == null || type.isEmpty()) return userSkillRepository.findByUserId(userId);
        return userSkillRepository.findByUserIdAndType(userId, type.toUpperCase());
    }

    /**
     * Search & discovery: find users who OFFER a given skill, optionally
     * filtered by proficiency. Used by the "Find Mentors" page.
     */
    public List<Map<String, Object>> searchMentorsBySkill(String skillName, String proficiency) {
        List<UserSkill> offerings = userSkillRepository.findOfferingUsersBySkillName(skillName);

        if (proficiency != null && !proficiency.isEmpty()) {
            offerings = offerings.stream()
                    .filter(o -> o.getProficiency().equalsIgnoreCase(proficiency))
                    .collect(Collectors.toList());
        }

        List<Map<String, Object>> results = new ArrayList<>();
        for (UserSkill os : offerings) {
            Optional<User> u = userRepository.findById(os.getUserId());
            if (u.isEmpty()) continue;
            Map<String, Object> entry = new HashMap<>();
            entry.put("userId", u.get().getUserId());
            entry.put("name", u.get().getName());
            entry.put("skillName", os.getSkillName());
            entry.put("proficiency", os.getProficiency());
            results.add(entry);
        }
        return results;
    }
}
