package com.example.skillexchange.service;

import com.example.skillexchange.dto.DashboardDto;
import com.example.skillexchange.dto.MatchDto;
import com.example.skillexchange.dto.ProfileUpdateRequest;
import com.example.skillexchange.dto.UserProfileDto;
import com.example.skillexchange.model.*;
import com.example.skillexchange.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/** Business logic for user profiles and the aggregated dashboard view. */
@Service
public class UserService {

    @Autowired private UserRepository userRepository;
    @Autowired private ProfileRepository profileRepository;
    @Autowired private UserSkillRepository userSkillRepository;
    @Autowired private RatingRepository ratingRepository;
    @Autowired private MentorshipRequestRepository requestRepository;
    @Autowired private SessionRepository sessionRepository;
    @Autowired private MatchingService matchingService;

    public UserProfileDto getFullProfile(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        Profile profile = profileRepository.findByUserId(userId).orElse(new Profile());

        UserProfileDto dto = new UserProfileDto();
        dto.setUserId(user.getUserId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setPhotoUrl(profile.getPhotoUrl());
        dto.setBio(profile.getBio());
        dto.setInterests(profile.getInterests());
        dto.setLearningGoals(profile.getLearningGoals());
        dto.setPreferredMentorshipType(profile.getPreferredMentorshipType());
        dto.setProfileCompletion(profile.getProfileCompletion());
        dto.setSkillsOffered(userSkillRepository.findByUserIdAndType(userId, "OFFERED"));
        dto.setSkillsWanted(userSkillRepository.findByUserIdAndType(userId, "WANTED"));

        double[] ratingInfo = ratingRepository.getAverageAndCount(userId);
        dto.setAverageRating(Math.round(ratingInfo[0] * 100.0) / 100.0);
        dto.setTotalRatings((int) ratingInfo[1]);

        return dto;
    }

    public UserProfileDto updateProfile(Long userId, ProfileUpdateRequest req) {
        userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));

        if (req.getName() != null && !req.getName().trim().isEmpty()) {
            userRepository.updateName(userId, req.getName().trim());
        }

        Profile profile = profileRepository.findByUserId(userId).orElseGet(() -> profileRepository.createEmpty(userId));
        profile.setUserId(userId);
        if (req.getPhotoUrl() != null) profile.setPhotoUrl(req.getPhotoUrl());
        if (req.getBio() != null) profile.setBio(req.getBio());
        if (req.getInterests() != null) profile.setInterests(req.getInterests());
        if (req.getLearningGoals() != null) profile.setLearningGoals(req.getLearningGoals());
        if (req.getPreferredMentorshipType() != null) profile.setPreferredMentorshipType(req.getPreferredMentorshipType());

        profile.setProfileCompletion(calculateCompletion(profile, userId));
        profileRepository.update(profile);

        return getFullProfile(userId);
    }

    /** Profile completion percentage - simple weighted checklist. */
    private int calculateCompletion(Profile p, Long userId) {
        int score = 0;
        if (p.getBio() != null && !p.getBio().trim().isEmpty()) score += 20;
        if (p.getPhotoUrl() != null && !p.getPhotoUrl().trim().isEmpty()) score += 15;
        if (p.getInterests() != null && !p.getInterests().trim().isEmpty()) score += 15;
        if (p.getLearningGoals() != null && !p.getLearningGoals().trim().isEmpty()) score += 15;
        if (!userSkillRepository.findByUserIdAndType(userId, "OFFERED").isEmpty()) score += 20;
        if (!userSkillRepository.findByUserIdAndType(userId, "WANTED").isEmpty()) score += 15;
        return Math.min(100, score);
    }

    public DashboardDto getDashboard(Long userId) {
        UserProfileDto profile = getFullProfile(userId);

        DashboardDto dto = new DashboardDto();
        dto.setProfileCompletion(profile.getProfileCompletion());
        dto.setSkillsOffered(profile.getSkillsOffered());
        dto.setSkillsWanted(profile.getSkillsWanted());
        dto.setAverageRating(profile.getAverageRating());
        dto.setTotalRatings(profile.getTotalRatings());

        List<MatchDto> topMatches = matchingService.findMatchesForUser(userId, 5);
        dto.setTopMatches(topMatches);

        List<MentorshipRequest> pending = requestRepository.findPendingByReceiverId(userId);
        dto.setPendingRequests(pending);

        List<Session> upcoming = sessionRepository.findByUserIdAndStatus(userId, "SCHEDULED");
        dto.setUpcomingSessions(upcoming);

        List<Session> completed = sessionRepository.findByUserIdAndStatus(userId, "COMPLETED");
        dto.setCompletedSessions(completed);

        return dto;
    }
}
