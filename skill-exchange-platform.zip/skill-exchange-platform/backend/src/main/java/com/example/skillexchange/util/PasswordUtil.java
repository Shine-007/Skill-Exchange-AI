package com.example.skillexchange.util;

import java.security.MessageDigest;
import java.io.UnsupportedEncodingException;

/**
 * Simple, dependency-free password hashing using salted SHA-256.
 * (A production system should use BCrypt/Argon2; SHA-256+salt keeps this
 * project easy to run without extra security-library setup while still
 * never storing plain-text passwords.)
 */
public class PasswordUtil {

    private static final String SALT = "skillexchange_salt";

    public static String hash(String rawPassword) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest((rawPassword + SALT).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    public static boolean matches(String rawPassword, String hashedPassword) {
        return hash(rawPassword).equals(hashedPassword);
    }
}
