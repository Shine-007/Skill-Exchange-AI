package com.example.skillexchange.util;

import java.util.Base64;
import java.util.UUID;

/**
 * Lightweight in-memory session token generator.
 * For a student/demo project we avoid a full JWT/Spring-Security setup;
 * AuthService keeps a Map<token, userId> to validate requests instead.
 */
public class TokenUtil {
    public static String generateToken(long userId) {
        String raw = userId + "-" + UUID.randomUUID().toString();
        return Base64.getEncoder().encodeToString(raw.getBytes());
    }
}
