package com.example.skillexchange.util;

import java.util.regex.Pattern;

/**
 * Small helper for validating user input across the application.
 * Keeping validation centralized avoids duplicating regex/logic in
 * every service class.
 */
public class ValidationUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean isValidPassword(String password) {
        // At least 6 characters - keep simple for a student project demo
        return password != null && password.length() >= 6;
    }

    public static boolean isNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    public static boolean isValidStarRating(int stars) {
        return stars >= 1 && stars <= 5;
    }

    public static boolean isValidDuration(int minutes) {
        return minutes == 15 || minutes == 30 || minutes == 45 || minutes == 60;
    }
}
