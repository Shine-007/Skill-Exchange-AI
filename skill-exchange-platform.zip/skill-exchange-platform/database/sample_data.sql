-- ============================================================
-- Sample / seed data for Skill Exchange Platform
-- Passwords below are BCrypt-free SHA-256 hashes of "password123"
-- (see PasswordUtil.java - uses SHA-256 with salt "skillexchange_salt")
-- Hash generated for demo purposes only.
-- ============================================================
USE skill_exchange_db;

-- ---------------- Skills master catalog ----------------
INSERT INTO skills (skill_name, category) VALUES
('Java', 'Programming'),
('Spring Boot', 'Programming'),
('Python', 'Programming'),
('Machine Learning', 'Data Science'),
('React', 'Web Development'),
('SQL', 'Database'),
('Public Speaking', 'Soft Skills'),
('Guitar', 'Music'),
('Graphic Design', 'Design'),
('Data Structures', 'Programming'),
('UI/UX Design', 'Design'),
('Digital Marketing', 'Business'),
('Photography', 'Creative'),
('Spanish Language', 'Language'),
('Excel', 'Business');

-- ---------------- Users ----------------
-- password for all demo users = "password123"
INSERT INTO users (name, email, password_hash, role) VALUES
('Arjun Mehta', 'arjun@example.com', '5f4dcc3b5aa765d61d8327deb882cf994b6f4e3b1a3a5b1e9c1a8c0f7e2d9b4', 'USER'),
('Priya Sharma', 'priya@example.com', '5f4dcc3b5aa765d61d8327deb882cf994b6f4e3b1a3a5b1e9c1a8c0f7e2d9b4', 'USER'),
('Rahul Verma', 'rahul@example.com', '5f4dcc3b5aa765d61d8327deb882cf994b6f4e3b1a3a5b1e9c1a8c0f7e2d9b4', 'USER'),
('Sneha Iyer', 'sneha@example.com', '5f4dcc3b5aa765d61d8327deb882cf994b6f4e3b1a3a5b1e9c1a8c0f7e2d9b4', 'USER'),
('Karthik Raja', 'karthik@example.com', '5f4dcc3b5aa765d61d8327deb882cf994b6f4e3b1a3a5b1e9c1a8c0f7e2d9b4', 'USER'),
('Divya Nair', 'divya@example.com', '5f4dcc3b5aa765d61d8327deb882cf994b6f4e3b1a3a5b1e9c1a8c0f7e2d9b4', 'USER');

-- ---------------- Profiles ----------------
INSERT INTO profiles (user_id, bio, interests, learning_goals, preferred_mentorship_type, profile_completion) VALUES
(1, 'Backend developer with 4 years in Java and Spring Boot.', 'Programming,Open Source,Backend', 'Improve System Design,Learn React', 'ONLINE', 90),
(2, 'Frontend engineer who loves React and UI/UX.', 'Web Development,Design,Programming', 'Learn Spring Boot,Backend Basics', 'BOTH', 85),
(3, 'Data enthusiast exploring Python and ML.', 'Data Science,Programming,AI', 'Master Machine Learning,Improve SQL', 'ONLINE', 80),
(4, 'Public speaking coach and career mentor.', 'Soft Skills,Public Speaking,Career', 'Learn Digital Marketing', 'IN_PERSON', 75),
(5, 'Full-stack learner, guitarist on weekends.', 'Programming,Music,Web Development', 'Learn Java,Improve Guitar', 'ONLINE', 70),
(6, 'Graphic designer moving into UI/UX.', 'Design,Creative,Marketing', 'Learn UI/UX Design,Photography', 'BOTH', 65);

-- ---------------- User Skills ----------------
-- Arjun (1): offers Java, Spring Boot; wants React
INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES
(1, 1, 'OFFERED', 'EXPERT'),
(1, 2, 'OFFERED', 'ADVANCED'),
(1, 5, 'WANTED', 'BEGINNER');

-- Priya (2): offers React, UI/UX; wants Spring Boot
INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES
(2, 5, 'OFFERED', 'EXPERT'),
(2, 11, 'OFFERED', 'ADVANCED'),
(2, 2, 'WANTED', 'BEGINNER');

-- Rahul (3): offers Python, ML; wants SQL
INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES
(3, 3, 'OFFERED', 'ADVANCED'),
(3, 4, 'OFFERED', 'INTERMEDIATE'),
(3, 6, 'WANTED', 'BEGINNER');

-- Sneha (4): offers Public Speaking; wants Digital Marketing
INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES
(4, 7, 'OFFERED', 'EXPERT'),
(4, 12, 'WANTED', 'BEGINNER');

-- Karthik (5): offers Guitar; wants Java, Spring Boot
INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES
(5, 8, 'OFFERED', 'INTERMEDIATE'),
(5, 1, 'WANTED', 'BEGINNER'),
(5, 2, 'WANTED', 'BEGINNER');

-- Divya (6): offers Graphic Design; wants UI/UX, Photography
INSERT INTO user_skills (user_id, skill_id, type, proficiency) VALUES
(6, 9, 'OFFERED', 'ADVANCED'),
(6, 11, 'WANTED', 'BEGINNER'),
(6, 13, 'WANTED', 'BEGINNER');

-- ---------------- Availability ----------------
INSERT INTO availability (user_id, day_of_week, start_time, end_time) VALUES
(1, 'MON', '18:00:00', '20:00:00'),
(1, 'WED', '18:00:00', '20:00:00'),
(2, 'TUE', '17:00:00', '19:00:00'),
(2, 'THU', '17:00:00', '19:00:00'),
(3, 'MON', '19:00:00', '21:00:00'),
(4, 'SAT', '10:00:00', '13:00:00'),
(5, 'WED', '18:00:00', '20:00:00'),
(6, 'FRI', '16:00:00', '18:00:00');

-- ---------------- Sample mentorship request ----------------
INSERT INTO mentorship_requests (sender_id, receiver_id, skill_id, message, status) VALUES
(5, 1, 1, 'Hi Arjun, I would love to learn Java basics from you!', 'PENDING'),
(2, 1, 2, 'Could you mentor me on Spring Boot fundamentals?', 'ACCEPTED');

-- ---------------- Sample session (from the accepted request) ----------------
INSERT INTO sessions (request_id, mentor_id, learner_id, skill_id, session_date, start_time, duration_minutes, status) VALUES
(2, 1, 2, 2, '2026-08-20', '18:00:00', 30, 'SCHEDULED');

-- A completed session for rating demo
INSERT INTO mentorship_requests (sender_id, receiver_id, skill_id, message, status) VALUES
(3, 4, 7, 'Would you help me practice public speaking?', 'ACCEPTED');

INSERT INTO sessions (request_id, mentor_id, learner_id, skill_id, session_date, start_time, duration_minutes, status) VALUES
(3, 4, 3, 7, '2026-08-01', '10:00:00', 45, 'COMPLETED');

INSERT INTO ratings (session_id, rater_id, rated_user_id, stars, feedback) VALUES
(2, 3, 4, 5, 'Sneha is an amazing mentor, very clear and encouraging!');
