-- ============================================================
-- Skill Exchange & Micro-Mentorship Platform
-- MySQL Database Schema
-- ============================================================

DROP DATABASE IF EXISTS skill_exchange_db;
CREATE DATABASE skill_exchange_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skill_exchange_db;

-- ------------------------------------------------------------
-- USERS: core authentication table
-- ------------------------------------------------------------
CREATE TABLE users (
    user_id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)  NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255)  NOT NULL,
    role            ENUM('USER','ADMIN') NOT NULL DEFAULT 'USER',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active       BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- PROFILES: extended user information (1-to-1 with users)
-- ------------------------------------------------------------
CREATE TABLE profiles (
    profile_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id          BIGINT NOT NULL UNIQUE,
    photo_url        VARCHAR(255) DEFAULT NULL,
    bio              TEXT,
    interests        VARCHAR(500) DEFAULT NULL,   -- comma-separated tags
    learning_goals   VARCHAR(500) DEFAULT NULL,   -- comma-separated tags
    preferred_mentorship_type ENUM('ONLINE','IN_PERSON','BOTH') DEFAULT 'ONLINE',
    profile_completion INT DEFAULT 0,             -- 0-100 percentage
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_profiles_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SKILLS: master list of skills (shared catalog)
-- ------------------------------------------------------------
CREATE TABLE skills (
    skill_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    skill_name   VARCHAR(100) NOT NULL UNIQUE,
    category     VARCHAR(100) DEFAULT 'General',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- USER_SKILLS: many-to-many link between users and skills
-- type = OFFERED (I can teach this) or WANTED (I want to learn this)
-- ------------------------------------------------------------
CREATE TABLE user_skills (
    user_skill_id  BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id        BIGINT NOT NULL,
    skill_id       BIGINT NOT NULL,
    type           ENUM('OFFERED','WANTED') NOT NULL,
    proficiency    ENUM('BEGINNER','INTERMEDIATE','ADVANCED','EXPERT') DEFAULT 'BEGINNER',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_us_user  FOREIGN KEY (user_id)  REFERENCES users(user_id)  ON DELETE CASCADE,
    CONSTRAINT fk_us_skill FOREIGN KEY (skill_id) REFERENCES skills(skill_id) ON DELETE CASCADE,
    CONSTRAINT uq_user_skill_type UNIQUE (user_id, skill_id, type)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- AVAILABILITY: weekly time-slots a user is free for sessions
-- ------------------------------------------------------------
CREATE TABLE availability (
    availability_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    day_of_week     ENUM('MON','TUE','WED','THU','FRI','SAT','SUN') NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    CONSTRAINT fk_avail_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- MENTORSHIP_REQUESTS: request sent from a learner to a mentor
-- ------------------------------------------------------------
CREATE TABLE mentorship_requests (
    request_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    sender_id      BIGINT NOT NULL,     -- the requester (learner)
    receiver_id    BIGINT NOT NULL,     -- the mentor
    skill_id       BIGINT NOT NULL,     -- skill the request is about
    message        VARCHAR(500) DEFAULT NULL,
    status         ENUM('PENDING','ACCEPTED','REJECTED','CANCELLED') DEFAULT 'PENDING',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_req_sender   FOREIGN KEY (sender_id)   REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_req_receiver FOREIGN KEY (receiver_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_req_skill    FOREIGN KEY (skill_id)    REFERENCES skills(skill_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- MATCHES: cached AI match scores between two users (optional cache)
-- ------------------------------------------------------------
CREATE TABLE matches (
    match_id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id          BIGINT NOT NULL,   -- the user requesting recommendations
    matched_user_id  BIGINT NOT NULL,   -- the recommended user
    skill_match      DECIMAL(5,2) DEFAULT 0,
    goal_match       DECIMAL(5,2) DEFAULT 0,
    interest_match   DECIMAL(5,2) DEFAULT 0,
    level_match      DECIMAL(5,2) DEFAULT 0,
    availability_match DECIMAL(5,2) DEFAULT 0,
    overall_match    DECIMAL(5,2) DEFAULT 0,
    reason           VARCHAR(500) DEFAULT NULL,
    generated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_match_user    FOREIGN KEY (user_id)         REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_match_matched FOREIGN KEY (matched_user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT uq_match_pair UNIQUE (user_id, matched_user_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SESSIONS: scheduled micro-mentorship sessions
-- ------------------------------------------------------------
CREATE TABLE sessions (
    session_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id     BIGINT NOT NULL,
    mentor_id      BIGINT NOT NULL,
    learner_id     BIGINT NOT NULL,
    skill_id       BIGINT NOT NULL,
    session_date   DATE NOT NULL,
    start_time     TIME NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 30,   -- 15, 30, 45, 60
    status         ENUM('SCHEDULED','COMPLETED','CANCELLED') DEFAULT 'SCHEDULED',
    notes          VARCHAR(500) DEFAULT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sess_request FOREIGN KEY (request_id) REFERENCES mentorship_requests(request_id) ON DELETE CASCADE,
    CONSTRAINT fk_sess_mentor  FOREIGN KEY (mentor_id)  REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_sess_learner FOREIGN KEY (learner_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_sess_skill   FOREIGN KEY (skill_id)   REFERENCES skills(skill_id) ON DELETE CASCADE,
    CONSTRAINT chk_duration CHECK (duration_minutes IN (15,30,45,60))
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- RATINGS: feedback given after a completed session
-- ------------------------------------------------------------
CREATE TABLE ratings (
    rating_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id     BIGINT NOT NULL,
    rater_id       BIGINT NOT NULL,     -- who gives the rating
    rated_user_id  BIGINT NOT NULL,     -- who receives the rating
    stars          TINYINT NOT NULL,
    feedback        VARCHAR(1000) DEFAULT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rating_session FOREIGN KEY (session_id)    REFERENCES sessions(session_id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_rater   FOREIGN KEY (rater_id)      REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_rated   FOREIGN KEY (rated_user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT chk_stars CHECK (stars BETWEEN 1 AND 5),
    CONSTRAINT uq_session_rater UNIQUE (session_id, rater_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Helpful indexes for performance
-- ------------------------------------------------------------
CREATE INDEX idx_user_skills_user   ON user_skills(user_id);
CREATE INDEX idx_user_skills_skill  ON user_skills(skill_id);
CREATE INDEX idx_requests_receiver  ON mentorship_requests(receiver_id);
CREATE INDEX idx_requests_sender    ON mentorship_requests(sender_id);
CREATE INDEX idx_sessions_mentor    ON sessions(mentor_id);
CREATE INDEX idx_sessions_learner   ON sessions(learner_id);
CREATE INDEX idx_ratings_rated_user ON ratings(rated_user_id);
