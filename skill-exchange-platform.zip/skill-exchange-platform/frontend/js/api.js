/* ============================================================
   api.js - Central API client for the Skill Exchange Platform
   All frontend pages call the Spring Boot REST API through the
   helper functions below. Change API_BASE_URL if your backend
   runs on a different host/port.
   ============================================================ */

const API_BASE_URL = "http://localhost:8080/api";

/**
 * Generic fetch wrapper. Automatically attaches the auth token
 * (stored in localStorage after login) and parses the standard
 * { success, message, data } response envelope used by every endpoint.
 */
async function apiRequest(path, method = "GET", body = null) {
  const headers = { "Content-Type": "application/json" };
  const token = localStorage.getItem("se_token");
  if (token) headers["Authorization"] = token;

  const options = { method, headers };
  if (body !== null) options.body = JSON.stringify(body);

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, options);
  } catch (networkErr) {
    throw new Error("Cannot reach the server. Is the Spring Boot backend running on port 8080?");
  }

  let json;
  try {
    json = await response.json();
  } catch (parseErr) {
    throw new Error("Unexpected response from server.");
  }

  if (!response.ok || json.success === false) {
    throw new Error(json.message || "Request failed");
  }
  return json.data;
}

/* ---------------- Auth ---------------- */
const AuthAPI = {
  register: (name, email, password) => apiRequest("/auth/register", "POST", { name, email, password }),
  login: (email, password) => apiRequest("/auth/login", "POST", { email, password }),
  logout: () => apiRequest("/auth/logout", "POST"),
};

/* ---------------- Users / Profile ---------------- */
const UserAPI = {
  getProfile: (userId) => apiRequest(`/users/${userId}`),
  updateProfile: (userId, data) => apiRequest(`/users/${userId}`, "PUT", data),
  getDashboard: (userId) => apiRequest(`/users/${userId}/dashboard`),
};

/* ---------------- Skills ---------------- */
const SkillAPI = {
  getAllSkills: () => apiRequest("/skills"),
  addToCatalog: (skillName, category) => apiRequest("/skills", "POST", { skillName, category }),
  addUserSkill: (userId, skillName, category, type, proficiency) =>
    apiRequest("/skills/user", "POST", { userId, skillName, category, type, proficiency }),
  getUserSkills: (userId, type) => apiRequest(`/skills/user/${userId}${type ? `?type=${type}` : ""}`),
  removeUserSkill: (userSkillId, userId) => apiRequest(`/skills/user/${userSkillId}?userId=${userId}`, "DELETE"),
  searchMentors: (skillName, proficiency) =>
    apiRequest(`/skills/search?skillName=${encodeURIComponent(skillName)}${proficiency ? `&proficiency=${proficiency}` : ""}`),
};

/* ---------------- AI Matching ---------------- */
const MatchAPI = {
  getMatches: (userId, limit = 10) => apiRequest(`/matches/${userId}?limit=${limit}`),
};

/* ---------------- Mentorship Requests ---------------- */
const RequestAPI = {
  send: (senderId, receiverId, skillId, message) =>
    apiRequest("/requests", "POST", { senderId, receiverId, skillId, message }),
  listForUser: (userId) => apiRequest(`/requests/${userId}`),
  updateStatus: (requestId, status) => apiRequest(`/requests/${requestId}`, "PUT", { status }),
};

/* ---------------- Sessions ---------------- */
const SessionAPI = {
  schedule: (requestId, sessionDate, startTime, durationMinutes, notes) =>
    apiRequest("/sessions", "POST", { requestId, sessionDate, startTime, durationMinutes, notes }),
  listForUser: (userId) => apiRequest(`/sessions/${userId}`),
  complete: (sessionId) => apiRequest(`/sessions/${sessionId}/complete`, "PUT"),
  cancel: (sessionId) => apiRequest(`/sessions/${sessionId}/cancel`, "PUT"),
};

/* ---------------- Ratings ---------------- */
const RatingAPI = {
  submit: (sessionId, raterId, ratedUserId, stars, feedback) =>
    apiRequest("/ratings", "POST", { sessionId, raterId, ratedUserId, stars, feedback }),
  listForUser: (userId) => apiRequest(`/ratings/${userId}`),
  summary: (userId) => apiRequest(`/ratings/${userId}/summary`),
};

/* ---------------- Availability ---------------- */
const AvailabilityAPI = {
  add: (userId, dayOfWeek, startTime, endTime) =>
    apiRequest("/availability", "POST", { userId, dayOfWeek, startTime, endTime }),
  listForUser: (userId) => apiRequest(`/availability/${userId}`),
};

/* ---------------- Session/local-storage helpers ---------------- */
const SessionStore = {
  saveAuth(authResponse) {
    localStorage.setItem("se_token", authResponse.token);
    localStorage.setItem("se_userId", authResponse.userId);
    localStorage.setItem("se_name", authResponse.name);
    localStorage.setItem("se_email", authResponse.email);
  },
  getUserId() {
    return localStorage.getItem("se_userId");
  },
  getName() {
    return localStorage.getItem("se_name");
  },
  isLoggedIn() {
    return !!localStorage.getItem("se_token");
  },
  clear() {
    localStorage.removeItem("se_token");
    localStorage.removeItem("se_userId");
    localStorage.removeItem("se_name");
    localStorage.removeItem("se_email");
  },
};

/** Redirects to login if the user isn't authenticated. Call at the top of protected pages. */
function requireAuth() {
  if (!SessionStore.isLoggedIn()) {
    window.location.href = "login.html";
  }
}

function initials(name) {
  if (!name) return "?";
  return name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
