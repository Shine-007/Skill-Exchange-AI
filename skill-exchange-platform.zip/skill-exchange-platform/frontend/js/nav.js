/* ============================================================
   nav.js - Renders the shared navigation bar on every page.
   Include this after api.js and add <div id="navbar-root"></div>
   at the top of the <body>.
   ============================================================ */

function renderNavbar(activePage) {
  const root = document.getElementById("navbar-root");
  if (!root) return;

  const loggedIn = SessionStore.isLoggedIn();
  const name = SessionStore.getName();

  const links = [
    { href: "dashboard.html", label: "Dashboard", key: "dashboard" },
    { href: "find-mentors.html", label: "Find Mentors", key: "find-mentors" },
    { href: "ai-recommendations.html", label: "AI Matches", key: "ai-recommendations" },
    { href: "requests.html", label: "Requests", key: "requests" },
    { href: "sessions.html", label: "My Sessions", key: "sessions" },
  ];

  const linksHtml = loggedIn
    ? links
        .map(
          (l) =>
            `<a href="${l.href}" class="${activePage === l.key ? "active" : ""}">${l.label}</a>`
        )
        .join("")
    : "";

  const actionsHtml = loggedIn
    ? `<a href="profile.html" class="user-chip"><span>${initials(name)}</span> ${escapeHtml(name)}</a>
       <button class="btn btn-secondary btn-sm" onclick="handleLogout()">Logout</button>`
    : `<a href="login.html" class="btn btn-secondary btn-sm">Login</a>
       <a href="register.html" class="btn btn-primary btn-sm">Sign Up</a>`;

  root.innerHTML = `
    <nav class="navbar">
      <div class="navbar-inner">
        <a href="${loggedIn ? "dashboard.html" : "index.html"}" class="brand">
          <span class="logo-badge">SE</span> Skill Exchange
        </a>
        <div class="nav-links">${linksHtml}</div>
        <div class="nav-actions">${actionsHtml}</div>
      </div>
    </nav>
  `;
}

async function handleLogout() {
  try {
    await AuthAPI.logout();
  } catch (e) {
    /* ignore network errors on logout */
  }
  SessionStore.clear();
  window.location.href = "index.html";
}
